# Near Miss Safety App — Complete Local & Corporate Deployment Guide
> **Standard Operating Procedure (SOP) for On-Premise, Corporate Local Network (LAN), and Docker Hosting**  
> *Target Audience: System Administrators, Developers, DevOps Engineers, and AI Agents (Claude, ChatGPT, Antigravity)*

---

## 1. System Architecture & Port Mapping

| Environment | Port | Web Server Engine | Audience | Persistence |
| :--- | :--- | :--- | :--- | :--- |
| **Development** | `5173` | Vite Dev Server | Single developer | Stops when terminal exits |
| **Docker (Standard)** | `80` | Nginx Alpine | **All Company Staff** | **24/7 (Auto-restarts on reboot)** |
| **Docker (Alternative)**| `3000` / `8080` | Nginx Alpine | Staff (if Port 80 is occupied) | **24/7 (Auto-restarts on reboot)** |
| **Windows Native** | `3000` | Node.js `serve` + PM2 | Staff (without Docker) | Background Windows Service |

---

## 2. Method A: Docker Deployment (Recommended Standard)

The project includes an optimized multi-stage build:
- `Dockerfile`: Compiles React via Node 20, then serves static files using ultra-lightweight Nginx Alpine.
- `nginx.conf`: Configures SPA routing (`try_files $uri /index.html;`) and Gzip compression.
- `.dockerignore`: Prevents transferring `node_modules` into the build context.
- `docker-compose.yml`: Binds host port `80` to container port `80` with `restart: unless-stopped`.

### Exact Command Lines:
```bash
# 1. Open a terminal in the project directory
cd /path/to/project

# 2. Build and launch the container in the background
docker compose up -d --build

# 3. Verify the container is running and healthy
docker ps

# 4. View live web server logs
docker logs -f near_miss_safety_app
```

**Local verification:** Open `http://localhost` in any web browser.

---

## 3. Method B: Native Windows Server (Without Docker)

If Docker is not installed on the Windows server:

```cmd
:: 1. Compile the production bundle into the 'dist' directory
npm.cmd run build

:: 2. Install production static server and PM2 process manager
npm install -g serve pm2 pm2-windows-startup
pm2-startup install

:: 3. Run as a permanent background service on port 3000 with SPA fallback
pm2 serve dist 3000 --name "near-miss-app" --spa

:: 4. Save state so it automatically restarts on Windows reboot
pm2 save
```

---

## 4. Method C: Dedicated Linux Server (Ubuntu / Debian Native)

```bash
# 1. Install Nginx
sudo apt update && sudo apt install -y nginx

# 2. Copy the pre-built 'dist' folder to web root
sudo cp -r dist/* /var/www/html/

# 3. Ensure SPA fallback in /etc/nginx/sites-available/default:
# location / {
#     try_files $uri $uri/ /index.html;
# }

# 4. Test and restart Nginx
sudo nginx -t && sudo systemctl restart nginx
sudo ufw allow 80/tcp
```

---

## 5. Company Local Network Access (Allowing All Employees to Connect)

### Step 1: Identify the Server's Local IP Address
- **On Windows:** Run `ipconfig` and note down the **IPv4 Address** (e.g. `192.168.1.120`).
- **On Linux:** Run `hostname -I`.

### Step 2: Allow Inbound Traffic through the Server Firewall
- **Windows PowerShell (Run as Administrator):**
  ```powershell
  New-NetFirewallRule -DisplayName "Near Miss Safety App" -Direction Inbound -LocalPort 80,3000 -Protocol TCP -Action Allow
  ```
- **Linux (UFW):**
  ```bash
  sudo ufw allow 80/tcp
  ```

### Step 3: Employee Access URL
Any employee connected to the company Wi-Fi or local office network can access the app by opening their browser and typing:
```
http://<SERVER_IP_ADDRESS>
```
*(Example: `http://192.168.1.120` or `http://192.168.1.120:3000` if using port 3000)*

---

## 6. Docker Management Quick Reference

| Task | Command Line | Notes |
| :--- | :--- | :--- |
| **Check container health** | `docker ps` | Confirms port `80` binding and uptime |
| **View real-time logs** | `docker logs -f near_miss_safety_app` | Shows live HTTP requests and errors |
| **Stop application** | `docker compose down` | Stops and removes container cleanly |
| **Restart application** | `docker compose restart` | Quick restart without rebuilding |
| **Rebuild after updates** | `docker compose up -d --build` | Re-compiles code and replaces image |

---

## 7. Troubleshooting & Common Pitfalls

1. **`ERR_CONNECTION_REFUSED`**:
   - Cause: The Docker container or background server is stopped.
   - Fix: Execute `docker compose up -d`.
2. **Port 80 is occupied (e.g. by Windows IIS or Skype)**:
   - Fix: In `docker-compose.yml`, change `"80:80"` to `"3000:80"` or `"8080:80"`. Employees then access via `http://<IP>:3000`.
3. **Coworkers cannot reach the page**:
   - Verify the server's Firewall inbound rule is active.
   - Verify the coworker is connected to the same company office subnet (not a restricted guest Wi-Fi).
4. **404 error when refreshing sub-pages**:
   - Ensure the Nginx configuration includes `try_files $uri $uri/ /index.html;` (already configured in `nginx.conf`).

---

## 8. Data Persistence Architecture Note
Currently, this frontend application executes client-side. For centralized database persistence where incidents submitted by one employee appear in real time for safety managers across other workstations, connect a shared backend (such as an Express API with SQLite/PostgreSQL or PocketBase) directly in `docker-compose.yml`.
