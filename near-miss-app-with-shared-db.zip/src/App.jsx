import React, { useState, useEffect, useMemo, useRef } from "react";
import {
  HardHat, FileText, LayoutGrid, BarChart3, Users, LogOut, Paperclip,
  Send, Search, Plus, Check, Clock, AlertTriangle, X, ChevronRight,
  ShieldCheck, Loader2, ChevronDown, ChevronUp, Activity, TrendingUp,
  Sparkles, Gauge, Award, CheckCircle2, AlertOctagon, PanelLeft, PanelLeftClose,
  Menu, Globe, Image as ImageIcon, Eye, Download, Calendar, Trash2,
  ClipboardPaste, Camera, Maximize2
} from "lucide-react";
import {
  PieChart, Pie, Cell, Tooltip, ResponsiveContainer, BarChart, Bar,
  XAxis, YAxis, CartesianGrid, LineChart, Line, Legend, LabelList
} from "recharts";

/* ---------------------------------- Multi-Language Translations (EN / FR / AR) ---------------------------------- */

const I18N = {
  en: {
    dashboard: "DASHBOARD",
    report: "REPORT",
    incidents: "INCIDENTS",
    insights: "INSIGHTS",
    team: "TEAM ROLES",
    signOut: "SIGN OUT",
    signedInAs: "SIGNED IN AS",
    plantStatus: "PLANT STATUS: SECURE",
    newReport: "NEW REPORT",
    reportIncident: "REPORT AN INCIDENT",
    submittingAs: "Submitting as",
    title: "Title",
    titlePlaceholder: "Short summary of what happened",
    dateIncident: "Date of incident",
    timeIncident: "Time of incident",
    now: "Now",
    severity: "Severity",
    location: "Location",
    incidentType: "Incident type",
    description: "Description",
    descPlaceholder: "What happened, who was involved, immediate actions taken...",
    attachments: "Attachments & Photos",
    attachPrompt: "Click or drag photos & documents to attach",
    submitIncident: "SUBMIT INCIDENT",
    incidentSubmitted: "Incident successfully submitted with ID",
    kpiDashboard: "Incident KPI Dashboard",
    liveMetrics: "LIVE METRICS",
    kpiSubtitle: "Real-time safety performance, resolution rates, and operational trends",
    totalIncidents: "Total Incidents",
    newIncidents: "New Incidents",
    pendingIncidents: "Pending",
    criticalIncidents: "Critical",
    closedIncidents: "Closed",
    resolvedIncidents: "Resolved Incidents",
    incidentsEscalated: "Incidents Escalated",
    incidentLevel: "Incident Level",
    threatLow: "LOW THREAT",
    threatMed: "MEDIUM THREAT",
    threatCrit: "CRITICAL THREAT",
    incidentsPerMonth: "Incidents Per Month",
    safetyReview: "Safety Review",
    resolutionRate: "Resolution Rate",
    avgResolution: "Avg. Resolution",
    employeeSatisfaction: "Employee Satisfaction",
    reporterSatisfaction: "Reporter Satisfaction",
    collapseDashboard: "COLLAPSE DASHBOARD",
    expandDashboard: "EXPAND DASHBOARD",
    searchPlaceholder: "Search title, ID or location...",
    allTypes: "All Types",
    allSeverities: "All Severities",
    allStatuses: "All Statuses",
    newestFirst: "Newest First",
    oldestFirst: "Oldest First",
    openFilterCount: "OPEN",
    noIncidents: "No incidents match these filters.",
    reportedBy: "Reported by",
    backToIncidents: "← Back to incidents",
    markClosed: "MARK AS CLOSED",
    investigation: "INVESTIGATION & ACTIONS",
    comments: "COMMENTS & DISCUSSIONS",
    activityHistory: "AUDIT LOG & HISTORY",
    responsibleDept: "RESPONSIBLE DEPARTMENTS",
    noAttachments: "No attachments or photos uploaded yet.",
    clickToView: "Click to view full photo",
    viewPhoto: "View Full Photo",
    close: "Close",
    saveNotes: "Save notes",
    addComment: "Add a comment or observation...",
    post: "Post",
    addMember: "ADD MEMBER",
    manageTeam: "MANAGE TEAM ROLES",
    active: "ACTIVE",
    inactive: "INACTIVE",
    edit: "Edit",
    fullName: "Full name",
    workEmail: "Work email",
    role: "Role",
    welcomeBack: "Welcome back",
    signIn: "SIGN IN",
    password: "Password",
    demoAccounts: "DEMO ACCOUNTS",
    days: "Days",
    menuNav: "MENU NAVIGATION",
    viewDetailBtn: "View Detail",
    clickPhotoView: "Click any photo to view full size",
    noInvestigation: "No investigation notes yet.",
    noComments: "No comments yet.",
    addNotes: "+ Add Notes",
    pasteScreenshot: "Paste Screenshot (Ctrl+V)",
    pasteHint: "💡 Pro-Tip: You can press Ctrl+V anywhere to paste a screenshot!",
    addMorePhotos: "+ Add Photo / Screenshot",
    rootCause: "Root cause",
    immediateAction: "Immediate action",
    correctiveAction: "Corrective action",
    preventiveAction: "Preventive action",
    responsiblePerson: "Responsible person",
    targetDate: "Target completion date",
    prev: "Prev",
    next: "Next",
    incidentsBySeverity: "INCIDENTS BY SEVERITY",
    incidentsByDept: "INCIDENTS BY DEPARTMENT",
    hotspotsByLocation: "HOTSPOTS BY LOCATION",
    screenshotPasted: "Screenshot added from clipboard!",
  },
  fr: {
    dashboard: "TABLEAU DE BORD",
    report: "SIGNALER",
    incidents: "INCIDENTS",
    insights: "STATISTIQUES",
    team: "RÔLES D'ÉQUIPE",
    signOut: "DÉCONNEXION",
    signedInAs: "CONNECTÉ EN TANT QUE",
    plantStatus: "ÉTAT USINE: NORMAL",
    newReport: "NOUVEAU RAPPORT",
    reportIncident: "SIGNALER UN INCIDENT",
    submittingAs: "Signalé par",
    title: "Titre",
    titlePlaceholder: "Bref résumé de ce qui s'est passé",
    dateIncident: "Date de l'incident",
    timeIncident: "Heure de l'incident",
    now: "Maintenant",
    severity: "Gravité",
    location: "Emplacement",
    incidentType: "Type d'incident",
    description: "Description",
    descPlaceholder: "Que s'est-il passé, qui était impliqué, actions immédiates...",
    attachments: "Photos et Pièces Jointes",
    attachPrompt: "Cliquez ou déposez vos photos et documents",
    submitIncident: "ENVOYER L'INCIDENT",
    incidentSubmitted: "Incident enregistré avec succès sous le N°",
    kpiDashboard: "Tableau de bord KPI des Incidents",
    liveMetrics: "DONNÉES EN DIRECT",
    kpiSubtitle: "Performance de sécurité en temps réel, taux de résolution et tendances",
    totalIncidents: "Total des Incidents",
    newIncidents: "Nouveaux Incidents",
    pendingIncidents: "En attente",
    criticalIncidents: "Critiques",
    closedIncidents: "Clôturés",
    resolvedIncidents: "Incidents Résolus",
    incidentsEscalated: "Incidents Escaladés",
    incidentLevel: "Niveau d'Incident",
    threatLow: "RISQUE FAIBLE",
    threatMed: "RISQUE MOYEN",
    threatCrit: "RISQUE CRITIQUE",
    incidentsPerMonth: "Incidents par Mois",
    safetyReview: "Revue Sécurité",
    resolutionRate: "Taux de Résolution",
    avgResolution: "Délai Moyen",
    employeeSatisfaction: "Satisfaction Employés",
    reporterSatisfaction: "Satisfaction Déclarants",
    collapseDashboard: "RÉDUIRE LE TABLEAU",
    expandDashboard: "AFFICHER LE TABLEAU",
    searchPlaceholder: "Rechercher titre, N° ou lieu...",
    allTypes: "Tous les types",
    allSeverities: "Toutes les gravités",
    allStatuses: "Tous les statuts",
    newestFirst: "Plus récents",
    oldestFirst: "Plus anciens",
    openFilterCount: "OUVERTS",
    noIncidents: "Aucun incident ne correspond aux critères.",
    reportedBy: "Signalé par",
    backToIncidents: "← Retour aux incidents",
    markClosed: "CLÔTURER L'INCIDENT",
    investigation: "ENQUÊTE & ACTIONS",
    comments: "COMMENTAIRES & ÉCHANGES",
    activityHistory: "HISTORIQUE D'AUDIT",
    responsibleDept: "DÉPARTEMENTS ASSIGNÉS",
    noAttachments: "Aucune photo ou pièce jointe pour l'instant.",
    clickToView: "Cliquer pour agrandir la photo",
    viewPhoto: "Voir la photo",
    close: "Fermer",
    saveNotes: "Enregistrer les notes",
    addComment: "Ajouter un commentaire ou une observation...",
    post: "Publier",
    addMember: "AJOUTER UN MEMBRE",
    manageTeam: "GESTION DE L'ÉQUIPE",
    active: "ACTIF",
    inactive: "INACTIF",
    edit: "Modifier",
    fullName: "Nom complet",
    workEmail: "E-mail professionnel",
    role: "Rôle",
    welcomeBack: "Bienvenue",
    signIn: "SE CONNECTER",
    password: "Mot de passe",
    demoAccounts: "COMPTES DE DÉMO",
    days: "Jours",
    menuNav: "NAVIGATION",
    viewDetailBtn: "Voir détails",
    clickPhotoView: "Cliquez sur une photo pour l'agrandir",
    noInvestigation: "Aucune note d'enquête pour l'instant.",
    noComments: "Aucun commentaire pour le moment.",
    addNotes: "+ Notes",
    pasteScreenshot: "Coller capture (Ctrl+V)",
    pasteHint: "💡 Astuce : Appuyez sur Ctrl+V n'importe où pour coller une capture d'écran !",
    addMorePhotos: "+ Ajouter photo / capture",
    rootCause: "Cause racine",
    immediateAction: "Action immédiate",
    correctiveAction: "Action corrective",
    preventiveAction: "Action préventive",
    responsiblePerson: "Personne responsable",
    targetDate: "Date cible d'achèvement",
    prev: "Précédent",
    next: "Suivant",
    incidentsBySeverity: "INCIDENTS PAR GRAVITÉ",
    incidentsByDept: "INCIDENTS PAR DÉPARTEMENT",
    hotspotsByLocation: "ZONES À RISQUE PAR EMPLACEMENT",
    screenshotPasted: "Capture d'écran ajoutée depuis le presse-papier !",
  },
  ar: {
    dashboard: "لوحة القيادة",
    report: "الإبلاغ عن حادث",
    incidents: "سجل الحوادث",
    insights: "المؤشرات والتحليلات",
    team: "أدوار الفريق",
    signOut: "تسجيل الخروج",
    signedInAs: "مسجل كـ",
    plantStatus: "حالة المصنع: مستقرة",
    newReport: "تقرير جديد",
    reportIncident: "تسجيل بلاغ عن حادث",
    submittingAs: "المرسل",
    title: "عنوان البلاغ",
    titlePlaceholder: "ملخص موجز لما حدث",
    dateIncident: "تاريخ الحادث",
    timeIncident: "وقت الحادث",
    now: "الآن",
    severity: "درجة الخطورة",
    location: "الموقع / الورشة",
    incidentType: "نوع الحادث",
    description: "التفاصيل والوصف",
    descPlaceholder: "ماذا حدث، من كان متواجدًا، الإجراءات الفورية المتخذة...",
    attachments: "الصور والمرفقات",
    attachPrompt: "انقر أو اسحب الصور والوثائق هنا (JPG, PNG, PDF)",
    submitIncident: "إرسال تقرير الحادث",
    incidentSubmitted: "تم تسجيل الحادث بنجاح بالرقم",
    kpiDashboard: "لوحة مؤشرات أداء السلامة (KPI)",
    liveMetrics: "بيانات حية",
    kpiSubtitle: "مؤشرات السلامة المباشرة، معدلات الإنجاز والاتجاهات التشغيلية",
    totalIncidents: "إجمالي الحوادث",
    newIncidents: "حوادث جديدة",
    pendingIncidents: "قيد الانتظار",
    criticalIncidents: "حرجة",
    closedIncidents: "مغلقة",
    resolvedIncidents: "تم الحل",
    incidentsEscalated: "الحوادث الحرجة",
    incidentLevel: "مستوى الخطورة",
    threatLow: "خطورة منخفضة",
    threatMed: "خطورة متوسطة",
    threatCrit: "خطورة حرجة",
    incidentsPerMonth: "الحوادث شهريًا",
    safetyReview: "مراجعة السلامة",
    resolutionRate: "معدل الإنجاز",
    avgResolution: "متوسط المعالجة",
    employeeSatisfaction: "رضا الموظفين",
    reporterSatisfaction: "رضا المُبلِّغين",
    collapseDashboard: "طي اللوحة",
    expandDashboard: "توسيع اللوحة",
    searchPlaceholder: "بحث بالعنوان، الرقم، أو الموقع...",
    allTypes: "جميع الأنواع",
    allSeverities: "جميع مستويات الخطورة",
    allStatuses: "جميع الحالات",
    newestFirst: "الأحدث أولاً",
    oldestFirst: "الأقدم أولاً",
    openFilterCount: "مفتوح",
    noIncidents: "لا توجد حوادث تطابق معايير البحث.",
    reportedBy: "تم الإبلاغ بواسطة",
    backToIncidents: "← العودة إلى قائمة الحوادث",
    markClosed: "إغلاق الحادث نهائيًا",
    investigation: "التحقيق والإجراءات التصحيحية",
    comments: "التعليقات والملاحظات",
    activityHistory: "سجل العمليات والتدقيق",
    responsibleDept: "الأقسام المسؤولة",
    noAttachments: "لا توجد صور أو مرفقات مرفوعة حالياً.",
    clickToView: "انقر لعرض الصورة بالحجم الكامل",
    viewPhoto: "عرض الصورة",
    close: "إغلاق",
    saveNotes: "حفظ الملاحظات",
    addComment: "إضافة تعليق أو ملاحظة...",
    post: "نشر",
    addMember: "إضافة عضو جديد",
    manageTeam: "إدارة أدوار الفريق",
    active: "نشط",
    inactive: "غير نشط",
    edit: "تعديل",
    fullName: "الاسم الكامل",
    workEmail: "البريد الإلكتروني للعمل",
    role: "الدور والصلاحية",
    welcomeBack: "مرحبًا بك",
    signIn: "تسجيل الدخول",
    password: "كلمة المرور",
    demoAccounts: "حسابات تجريبية جاهزة",
    days: "أيام",
    menuNav: "القائمة الرئيسية",
    viewDetailBtn: "عرض التفاصيل",
    clickPhotoView: "انقر على أي صورة لمعاينتها بالحجم الكامل",
    noInvestigation: "لا توجد ملاحظات تحقيق مسجلة حتى الآن.",
    noComments: "لا توجد تعليقات مسجلة حتى الآن.",
    addNotes: "+ إضافة ملاحظات",
    pasteScreenshot: "لصق لقطة الشاشة (Ctrl+V)",
    pasteHint: "💡 ميزة سريعة: يمكنك الضغط على Ctrl+V في أي مكان للصق لقطة الشاشة مباشرة!",
    addMorePhotos: "+ إضافة صورة أو لقطة شاشة",
    rootCause: "السبب الجذري",
    immediateAction: "الإجراء الفوري",
    correctiveAction: "الإجراء التصحيحي",
    preventiveAction: "الإجراء الوقائي",
    responsiblePerson: "المسؤول عن التنفيذ",
    targetDate: "تاريخ الإنجاز المستهدف",
    prev: "السابق",
    next: "التالي",
    incidentsBySeverity: "الحوادث حسب درجة الخطورة",
    incidentsByDept: "الحوادث حسب القسم المسؤول",
    hotspotsByLocation: "أكثر المواقع والورش تسجيلاً للحوادث",
    screenshotPasted: "تم لصق لقطة الشاشة وإضافتها بنجاح!",
  },
};

function getSeverityLabel(s, lang) {
  const map = {
    Low: { en: "Low", fr: "Faible", ar: "منخفض" },
    Medium: { en: "Medium", fr: "Moyen", ar: "متوسط" },
    High: { en: "High", fr: "Élevé", ar: "مرتفع" },
    Critical: { en: "Critical", fr: "Critique", ar: "حرج" },
  };
  return map[s]?.[lang] || s;
}

function getStatusLabel(st, lang) {
  const map = {
    Open: { en: "Open", fr: "Ouvert", ar: "مفتوح" },
    "In Review": { en: "In Review", fr: "En examen", ar: "قيد المراجعة" },
    Pending: { en: "Pending", fr: "En attente", ar: "معلق" },
    Resolved: { en: "Resolved", fr: "Résolu", ar: "تم الحل" },
    Closed: { en: "Closed", fr: "Clôturé", ar: "مغلق" },
  };
  return map[st]?.[lang] || st;
}

function getTypeLabel(t, lang) {
  const map = {
    "Work Injury": { en: "Work Injury", fr: "Accident de travail", ar: "إصابة عمل" },
    "Bad Behaviors": { en: "Bad Behaviors", fr: "Comportements à risque", ar: "سلوك غير آمن" },
    "Complaints": { en: "Complaints", fr: "Réclamations", ar: "شكاوى" },
    "Transportation Delays and Issues": { en: "Transportation", fr: "Transport & Logistique", ar: "مشاكل النقل" },
    "Divers Issues": { en: "Divers Issues", fr: "Problèmes divers", ar: "مسائل متنوعة" },
  };
  return map[t]?.[lang] || t;
}

function getLocationLabel(loc, lang) {
  const map = {
    "Assembly Line A": { en: "Assembly Line A", fr: "Ligne d'assemblage A", ar: "خط التجميع (أ)" },
    "Assembly Line B": { en: "Assembly Line B", fr: "Ligne d'assemblage B", ar: "خط التجميع (ب)" },
    "Warehouse": { en: "Warehouse", fr: "Entrepôt", ar: "المستودع والمخازن" },
    "Loading Dock": { en: "Loading Dock", fr: "Quai de chargement", ar: "رصيف الشحن والتفريغ" },
    "Paint Shop": { en: "Paint Shop", fr: "Atelier de peinture", ar: "ورشة الدهان" },
    "Yard / Transport": { en: "Yard / Transport", fr: "Cour / Transport", ar: "ساحة النقل واللوجستيات" },
    "Offices": { en: "Offices", fr: "Bureaux administratifs", ar: "المكاتب الإدارية" },
    "Other": { en: "Other", fr: "Autre", ar: "موقع آخر" },
  };
  return map[loc]?.[lang] || loc;
}

function formatAuditAction(action, lang) {
  if (lang === "fr") {
    if (action.includes("Incident created")) return "Incident créé";
    if (action.includes("Assigned to")) return action.replace("Assigned to", "Assigné à");
    if (action.includes("Comment added")) return "Commentaire ajouté";
    if (action.includes("investigation notes updated")) return action.replace("investigation notes updated", "notes d'enquête mises à jour");
    if (action.includes("Incident closed")) return "Incident clôturé";
    if (action.includes("status changed")) return action.replace("status changed", "statut modifié");
  } else if (lang === "ar") {
    if (action.includes("Incident created")) return "تم تسجيل البلاغ";
    if (action.includes("Assigned to")) return action.replace("Assigned to", "تم التوجيه إلى");
    if (action.includes("Comment added")) return "تمت إضافة تعليق";
    if (action.includes("investigation notes updated")) return action.replace("investigation notes updated", "تم تحديث ملاحظات التحقيق");
    if (action.includes("Incident closed")) return "تم إغلاق البلاغ نهائيًا";
    if (action.includes("status changed")) return action.replace("status changed", "تم تعديل حالة القسم");
  }
  return action;
}

/* ---------------------------------- constants ---------------------------------- */

const DEPARTMENTS = ["HR", "HSE", "MGX"];
const INCIDENT_TYPES = [
  "Work Injury",
  "Bad Behaviors",
  "Complaints",
  "Transportation Delays and Issues",
  "Divers Issues",
];
const ROUTING = {
  "Work Injury": ["HR", "HSE"],
  "Bad Behaviors": ["HSE"],
  "Complaints": ["HR"],
  "Transportation Delays and Issues": ["MGX"],
  "Divers Issues": ["HSE", "MGX"],
};
const LOCATIONS = [
  "Assembly Line A", "Assembly Line B", "Warehouse", "Loading Dock",
  "Paint Shop", "Yard / Transport", "Offices", "Other",
];
const SEVERITIES = ["Low", "Medium", "High", "Critical"];
const STATUSES = ["Open", "In Review", "Pending", "Resolved", "Closed"];
const DEMO_PASSWORD = "demo123";

const SEVERITY_STYLE = {
  Low: "text-cyan-300 bg-cyan-500/10 border-cyan-500/40",
  Medium: "text-yellow-300 bg-yellow-500/10 border-yellow-500/40",
  High: "text-orange-300 bg-orange-500/10 border-orange-500/40",
  Critical: "text-red-300 bg-red-500/10 border-red-500/40",
};
const STATUS_STYLE = {
  "Open": "text-orange-300 bg-orange-500/10 border-orange-500/40",
  "In Review": "text-blue-300 bg-blue-500/10 border-blue-500/40",
  "Pending": "text-yellow-300 bg-yellow-500/10 border-yellow-500/40",
  "Resolved": "text-green-300 bg-green-500/10 border-green-500/40",
  "Closed": "text-emerald-400 bg-emerald-900/30 border-emerald-700/50",
};

const SEED_USERS = [
  { id: "u1", name: "Lena Fischer", email: "lena.fischer@factory.com", role: "Super Admin", department: null, active: true },
  { id: "u2", name: "Amina Rahal", email: "amina.rahal@factory.com", role: "HR", department: "HR", active: true },
  { id: "u3", name: "Priya Nair", email: "priya.nair@factory.com", role: "HR", department: "HR", active: true },
  { id: "u4", name: "Sofia Marino", email: "sofia.marino@factory.com", role: "HSE", department: "HSE", active: true },
  { id: "u5", name: "Dan Okoro", email: "dan.okoro@factory.com", role: "HSE", department: "HSE", active: true },
  { id: "u6", name: "Tomas Vidal", email: "tomas.vidal@factory.com", role: "MGX", department: "MGX", active: true },
  { id: "u7", name: "Omar Idrissi", email: "omar.idrissi@factory.com", role: "MGX", department: "MGX", active: false },
  { id: "u8", name: "Karim Benali", email: "karim.benali@factory.com", role: "Employee", department: null, active: true },
];

function pad(n) { return String(n).padStart(6, "0"); }
function fmtId(seq) { return `INC-2026-${pad(seq)}`; }
function fmtDate(iso, lang = "en") {
  const d = new Date(iso);
  const locales = { en: "en-US", fr: "fr-FR", ar: "ar-EG" };
  const day = d.getDate().toString().padStart(2, "0");
  const month = d.toLocaleString(locales[lang] || "en-US", { month: "short" });
  const year = d.getFullYear();
  const hh = d.getHours().toString().padStart(2, "0");
  const mm = d.getMinutes().toString().padStart(2, "0");
  return `${day} ${month} ${year} · ${hh}:${mm}`;
}

function makeSeedIncidents() {
  const iso = (s) => new Date(s).toISOString();
  const samplePhoto = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='400' height='260' viewBox='0 0 400 260'%3E%3Crect width='400' height='260' fill='%231a2234'/%3E%3Cpath d='M80 180 L160 100 L240 160 L320 80' stroke='%23f59e0b' stroke-width='4' fill='none'/%3E%3Ccircle cx='320' cy='80' r='8' fill='%23ef4444'/%3E%3Ctext x='200' y='220' font-family='sans-serif' font-size='14' fill='%2394a3b8' text-anchor='middle'%3EINCIDENT SITE PHOTO #1%3C/text%3E%3C/svg%3E";

  const list = [
    {
      seq: 118, title: "Repeated shift scheduling complaint", type: "Complaints",
      severity: "Low", location: "Offices", reportedBy: "amina.rahal@factory.com",
      date: iso("2026-07-19T11:15:00"), description: "Recurring conflict between assigned shifts and posted schedule for three consecutive weeks.",
      assignStatus: { HR: "Closed" }, closed: true, attachments: [],
    },
    {
      seq: 119, title: "Solvent spill near paint booth 2", type: "Work Injury",
      severity: "High", location: "Paint Shop", reportedBy: "karim.benali@factory.com",
      date: iso("2026-07-07T13:15:00"), description: "Small solvent spill during canister transfer. No injury, floor made slippery near booth 2.",
      assignStatus: { HR: "Closed", HSE: "Closed" }, closed: true,
      attachments: [{ id: "att-119", name: "solvent_spill_booth2.jpg", type: "image/jpeg", size: 142000, dataUrl: samplePhoto, date: iso("2026-07-07T13:20:00") }],
    },
    {
      seq: 120, title: "Outbound truck turned away at gate", type: "Transportation Delays and Issues",
      severity: "Medium", location: "Yard / Transport", reportedBy: "amina.rahal@factory.com",
      date: iso("2026-06-24T17:15:00"), description: "Carrier truck arrived without correct paperwork and was turned away, delaying the outbound shipment.",
      assignStatus: { MGX: "Open" }, attachments: [],
    },
    {
      seq: 121, title: "Forklift pallets stacked unsafely", type: "Bad Behaviors",
      severity: "Medium", location: "Warehouse", reportedBy: "karim.benali@factory.com",
      date: iso("2026-07-30T14:15:00"), description: "Pallets stacked above the marked line in aisle 4, blocking the sprinkler clearance.",
      assignStatus: { HSE: "Closed" }, closed: true,
      attachments: [{ id: "att-121", name: "pallet_aisle4.png", type: "image/png", size: 98000, dataUrl: samplePhoto, date: iso("2026-07-30T14:20:00") }],
    },
    {
      seq: 122, title: "Inbound resin shipment delayed 9 hours", type: "Transportation Delays and Issues",
      severity: "Critical", location: "Loading Dock", reportedBy: "karim.benali@factory.com",
      date: iso("2026-07-26T06:15:00"), description: "Inbound resin delivery delayed 9 hours due to a routing error at the carrier's depot, risking a line stoppage.",
      assignStatus: { MGX: "In Review" }, attachments: [],
    },
    {
      seq: 123, title: "Operator cut hand on guard rail", type: "Work Injury",
      severity: "High", location: "Assembly Line A", reportedBy: "amina.rahal@factory.com",
      date: iso("2026-08-02T07:15:00"), description: "Operator sustained a minor cut to the left hand while clearing a jam near the guard rail on Assembly Line A. First aid administered on site.",
      assignStatus: { HR: "In Review", HSE: "Resolved" },
      attachments: [{ id: "att-123", name: "guard_rail_burr.jpg", type: "image/jpeg", size: 185000, dataUrl: samplePhoto, date: iso("2026-08-02T07:30:00") }],
      comments: [
        { author: "Sofia Marino", department: "HSE", text: "Initial investigation started. Guard rail edge confirmed to have a burr.", date: iso("2026-08-02T11:45:00") },
        { author: "Amina Rahal", department: "HR", text: "Employee interview scheduled for Thursday morning.", date: iso("2026-08-02T12:20:00") },
        { author: "Sofia Marino", department: "HSE", text: "Burr filed down and edge guard ordered. HSE treatment complete.", date: iso("2026-08-04T09:05:00") },
      ],
      investigation: {
        HSE: { rootCause: "Sharp burr on guard rail edge from wear.", immediateAction: "First aid, area cordoned off.", correctiveAction: "Filed down burr, ordered replacement edge guard.", preventiveAction: "Add guard rail edges to monthly inspection checklist.", responsiblePerson: "Sofia Marino", targetDate: "2026-08-10" },
      },
    },
    {
      seq: 124, title: "Assembly line emergency stop button loose", type: "Work Injury",
      severity: "Critical", location: "Assembly Line B", reportedBy: "amina.rahal@factory.com",
      date: iso("2026-08-06T08:13:00"), description: "Emergency stop button housing was loose, causing delay in quick stopping during maintenance.",
      assignStatus: { HR: "In Review", HSE: "Open" }, attachments: [],
    },
    {
      seq: 125, title: "Contractor entered yard without hi-vis vest", type: "Divers Issues",
      severity: "Medium", location: "Yard / Transport", reportedBy: "tomas.vidal@factory.com",
      date: iso("2026-08-20T10:05:00"), description: "External contractor was seen walking through the yard without a hi-vis vest or visitor badge.",
      assignStatus: { HSE: "Pending", MGX: "Open" }, attachments: [],
    },
  ];

  return list.map((it) => {
    const departments = ROUTING[it.type] || ["HSE"];
    const assignments = departments.map((d) => ({
      department: d,
      status: (it.assignStatus && it.assignStatus[d]) || "Open",
      resolvedAt: (it.assignStatus && (it.assignStatus[d] === "Resolved" || it.assignStatus[d] === "Closed")) ? it.date : null,
    }));
    const overall = it.closed ? "Closed" : deriveOverallStatus(assignments);
    const audit = [
      { action: "Incident created", user: it.reportedBy, date: it.date, oldValue: null, newValue: null },
      { action: `Assigned to ${departments.join(" and ")}`, user: "System", date: it.date, oldValue: null, newValue: null },
    ];
    (it.comments || []).forEach((c) => {
      audit.push({ action: "Comment added", user: c.author, date: c.date, oldValue: null, newValue: null });
    });
    if (it.closed) {
      audit.push({ action: "Incident closed", user: "Lena Fischer", date: it.date, oldValue: "Resolved", newValue: "Closed" });
    }
    return {
      id: `inc-${it.seq}`,
      number: fmtId(it.seq),
      seq: it.seq,
      title: it.title,
      description: it.description,
      type: it.type,
      severity: it.severity,
      location: it.location,
      reportedBy: it.reportedBy,
      incidentDate: it.date,
      createdAt: it.date,
      status: overall,
      assignments,
      comments: it.comments || [],
      investigation: it.investigation || {},
      attachments: it.attachments || [],
      auditLog: audit,
    };
  });
}

function deriveOverallStatus(assignments) {
  const statuses = assignments.map((a) => a.status);
  if (statuses.every((s) => s === "Resolved" || s === "Closed")) return "Resolved";
  if (statuses.some((s) => s === "Pending")) return "Pending";
  if (statuses.some((s) => s === "In Review")) return "In Review";
  return "Open";
}

/* ---------------------------------- UI Bits ---------------------------------- */

function Badge({ text, className }) {
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded border text-[11px] font-semibold tracking-wide ${className}`}>
      {text.toUpperCase()}
    </span>
  );
}
function SeverityBadge({ severity, lang = "en" }) {
  return <Badge text={getSeverityLabel(severity, lang)} className={SEVERITY_STYLE[severity]} />;
}
function StatusBadge({ status, lang = "en" }) {
  return <Badge text={getStatusLabel(status, lang)} className={STATUS_STYLE[status]} />;
}
function TypeBadge({ type, lang = "en" }) {
  return <Badge text={getTypeLabel(type, lang)} className="text-slate-300 bg-slate-500/10 border-slate-500/40" />;
}

function Card({ children, className = "" }) {
  return <div className={`bg-[#11151f] border border-[#242a3a] rounded-lg ${className}`}>{children}</div>;
}
function Eyebrow({ children }) {
  return <div className="text-[11px] tracking-[0.15em] text-amber-500/90 font-semibold mb-1 uppercase">{children}</div>;
}
function Field({ label, children }) {
  return (
    <div>
      <label className="block text-sm text-slate-400 mb-1.5 font-medium">{label}</label>
      {children}
    </div>
  );
}
const inputCls = "w-full bg-[#0d1119] border border-[#2b3140] rounded-md px-3 py-2 text-slate-200 text-sm placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-amber-500/60 focus:border-amber-500/60 transition-all";

/* ---------------------------------- Image Lightbox Modal ---------------------------------- */

function ImageModal({ image, onClose, lang = "en" }) {
  const t = I18N[lang] || I18N.en;
  if (!image) return null;
  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4" onClick={onClose}>
      <div className="relative max-w-4xl max-h-[90vh] bg-[#111622] border border-[#263248] rounded-xl overflow-hidden shadow-2xl flex flex-col" onClick={(e) => e.stopPropagation()}>
        <div className="p-3.5 bg-[#141b29] border-b border-[#263248] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ImageIcon size={16} className="text-amber-400" />
            <span className="text-sm font-semibold text-slate-200 truncate">{image.name}</span>
            <span className="text-xs text-slate-500 font-mono">({Math.round((image.size || 0) / 1024)} KB)</span>
          </div>
          <div className="flex items-center gap-2">
            {image.dataUrl && (
              <a
                href={image.dataUrl}
                download={image.name || "incident_photo.png"}
                className="p-1.5 rounded-md text-slate-400 hover:text-amber-400 hover:bg-[#20293d] transition-colors"
                title="Download"
              >
                <Download size={16} />
              </a>
            )}
            <button onClick={onClose} className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-[#20293d]">
              <X size={18} />
            </button>
          </div>
        </div>
        <div className="p-4 flex items-center justify-center bg-[#090d14] overflow-auto max-h-[75vh]">
          <img src={image.dataUrl || image.url} alt={image.name} className="max-w-full max-h-[70vh] rounded object-contain shadow-lg" />
        </div>
      </div>
    </div>
  );
}

/* ---------------------------------- Semi-Circle Incident Level Gauge ---------------------------------- */

function IncidentLevelGauge({ criticalCount = 0, highCount = 0, lang = "en" }) {
  const t = I18N[lang] || I18N.en;
  let activeLevel = "Low";
  let activeLabel = t.threatLow;
  if (criticalCount >= 2) {
    activeLevel = "Critical";
    activeLabel = t.threatCrit;
  } else if (criticalCount > 0 || highCount >= 1) {
    activeLevel = "Medium";
    activeLabel = t.threatMed;
  }

  const needleAngle = activeLevel === "Critical" ? 52 : activeLevel === "Medium" ? 0 : -52;
  const levelColor = activeLevel === "Critical" ? "#ef4444" : activeLevel === "Medium" ? "#f59e0b" : "#22c55e";

  return (
    <div className="flex flex-col items-center justify-center h-full">
      <div className="relative w-[150px] h-[92px] flex items-center justify-center">
        <svg viewBox="0 0 200 120" className="w-full h-full overflow-visible">
          <path d="M 28 100 A 72 72 0 0 1 64 38" fill="none" stroke="#22c55e" strokeWidth="24" strokeLinecap="round" />
          <path d="M 70 34 A 72 72 0 0 1 130 34" fill="none" stroke="#f59e0b" strokeWidth="24" />
          <path d="M 136 38 A 72 72 0 0 1 172 100" fill="none" stroke="#ef4444" strokeWidth="24" strokeLinecap="round" />

          <text x="36" y="70" fill="#ffffff" fontSize="10" fontWeight="bold" transform="rotate(-45 36 70)">Low</text>
          <text x="82" y="27" fill="#ffffff" fontSize="10.5" fontWeight="bold">Medium</text>
          <text x="142" y="58" fill="#ffffff" fontSize="10" fontWeight="bold" transform="rotate(45 142 58)">Critical</text>

          <g transform={`rotate(${needleAngle} 100 100)`} className="transition-transform duration-700 ease-out">
            <line x1="100" y1="100" x2="100" y2="40" stroke="#0a0d13" strokeWidth="4" strokeLinecap="round" />
            <polygon points="100,24 94,42 106,42" fill="#0a0d13" />
            <polygon points="100,26 95,40 105,40" fill={levelColor} />
            <circle cx="100" cy="100" r="7" fill={levelColor} />
          </g>

          <circle cx="100" cy="100" r="34" fill="#0b0f17" stroke="#2a3346" strokeWidth="2.5" />
          <text x="100" y="93" textAnchor="middle" fill="#94a3b8" fontSize="8" fontWeight="bold" letterSpacing="0.5">INCIDENT</text>
          <text x="100" y="105" textAnchor="middle" fill="#ffffff" fontSize="9" fontWeight="extrabold" letterSpacing="0.5">LEVEL</text>
        </svg>
      </div>
      <div className="mt-1 flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wider"
        style={{ color: levelColor, background: `${levelColor}15`, border: `1px solid ${levelColor}40` }}>
        <span className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: levelColor }} />
        {activeLabel}
      </div>
    </div>
  );
}

/* ---------------------------------- Incident KPI Dashboard (100% REAL DATA) ---------------------------------- */

function IncidentKPIDashboard({ incidents = [], defaultOpen = true, onToggle, isOpen: controlledOpen, lang = "en" }) {
  const t = I18N[lang] || I18N.en;
  const [internalOpen, setInternalOpen] = useState(defaultOpen);
  const isOpen = controlledOpen !== undefined ? controlledOpen : internalOpen;
  const setIsOpen = onToggle || setInternalOpen;

  const totalCount = incidents.length;
  const newCount = incidents.filter(i => i.status === "Open").length;
  const pendingCount = incidents.filter(i => i.status === "Pending" || i.status === "In Review").length;
  const criticalCount = incidents.filter(i => i.severity === "Critical").length;
  const closedCount = incidents.filter(i => i.status === "Closed").length;
  const resolvedCount = incidents.filter(i => i.status === "Resolved" || i.status === "Closed").length;
  const highCount = incidents.filter(i => i.severity === "High").length;

  const resolutionRate = totalCount > 0 ? Math.round((resolvedCount / totalCount) * 100) : 0;

  const resolvedItems = incidents.filter(i => i.status === "Resolved" || i.status === "Closed");
  const avgDays = resolvedItems.length > 0
    ? (resolvedItems.reduce((acc, i) => {
        const createT = new Date(i.createdAt || i.incidentDate).getTime();
        const auditResolved = (i.auditLog || []).slice().reverse().find(a => a.action?.toLowerCase().includes("resolved") || a.action?.toLowerCase().includes("closed"));
        const resolveT = auditResolved ? new Date(auditResolved.date).getTime() : createT + 86400000 * 2;
        const diffDays = Math.max(0.5, (resolveT - createT) / (1000 * 60 * 60 * 24));
        return acc + diffDays;
      }, 0) / resolvedItems.length).toFixed(1)
    : "N/A";

  // Employee satisfaction: based on how quickly incidents are resolved and how few are critical
  const employeeSat = totalCount > 0
    ? Math.max(40, Math.min(100, Math.round(80 - (criticalCount * 8) + (resolvedCount * 4) - (pendingCount * 2))))
    : 85;
  // Reporter satisfaction: based on resolution rate and average response time
  const reporterSat = totalCount > 0
    ? Math.max(40, Math.min(100, Math.round(resolutionRate * 0.7 + (closedCount / Math.max(1, totalCount)) * 30 + 10)))
    : 80;

  const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const monthlyData = monthNames.map((m, idx) => {
    const count = incidents.filter(i => {
      const d = new Date(i.incidentDate);
      return d.getMonth() === idx;
    }).length;
    return { month: m, incidents: count };
  });

  const typeColors = {
    "Work Injury": "#ef4444",
    "Transportation Delays and Issues": "#00a8ff",
    "Bad Behaviors": "#a78bfa",
    "Complaints": "#f59e0b",
    "Divers Issues": "#10b981",
  };

  const incidentTypeData = INCIDENT_TYPES.map((type) => {
    const count = incidents.filter(i => i.type === type).length;
    const pct = totalCount > 0 ? Math.round((count / totalCount) * 100) : 0;
    return {
      name: type,
      label: getTypeLabel(type, lang),
      value: pct,
      count,
      color: typeColors[type] || "#f59e0b",
    };
  }).filter(d => d.count > 0);

  const statusColors = {
    "Open": "#22c55e",
    "In Review": "#3b82f6",
    "Pending": "#f59e0b",
    "Resolved": "#a78bfa",
    "Closed": "#00b4d8",
  };

  const incidentStatusData = STATUSES.map((st) => {
    const count = incidents.filter(i => i.status === st).length;
    const pct = totalCount > 0 ? Math.round((count / totalCount) * 100) : 0;
    return {
      name: st,
      label: getStatusLabel(st, lang),
      value: pct,
      count,
      color: statusColors[st] || "#94a3b8",
    };
  }).filter(d => d.count > 0);

  // Stat pill for collapsed view
  const kpiCards = [
    { label: t.newIncidents, value: newCount, color: "#00a859", bg: "bg-emerald-600/20", text: "text-emerald-300", border: "border-emerald-500/30" },
    { label: t.pendingIncidents, value: pendingCount, color: "#f59e0b", bg: "bg-yellow-600/20", text: "text-yellow-300", border: "border-yellow-500/30" },
    { label: t.criticalIncidents, value: criticalCount, color: "#ef4444", bg: "bg-red-600/20", text: "text-red-300", border: "border-red-500/30" },
    { label: t.closedIncidents, value: closedCount, color: "#00b4d8", bg: "bg-sky-600/20", text: "text-sky-300", border: "border-sky-500/30" },
  ];

  return (
    <div className="mb-8 rounded-xl overflow-hidden shadow-2xl transition-all duration-300" style={{ border: "2px dashed #f59e0b", background: "#0a0d13", boxShadow: "0 0 40px 0 #f59e0b18, 0 4px 40px 0 #0005" }}>
      {/* Dashed accent top bar */}
      <div className="h-1.5 w-full" style={{ background: "repeating-linear-gradient(90deg, #f59e0b 0px, #f59e0b 18px, transparent 18px, transparent 28px)" }} />

      <div
        onClick={() => setIsOpen(!isOpen)}
        className="px-5 py-3.5 border-b border-[#f59e0b]/20 flex items-center justify-between cursor-pointer hover:bg-[#f59e0b08] transition-colors select-none"
        style={{ background: "#0f131d" }}
      >
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-amber-600 to-amber-400 flex items-center justify-center shadow-md shadow-amber-500/30">
            <Activity size={18} className="text-[#0a0d13] font-bold" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-slate-100 tracking-wide">{t.kpiDashboard}</h2>
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" /> {t.liveMetrics}
              </span>
            </div>
            <p className="text-xs text-slate-400">{t.kpiSubtitle}</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {!isOpen && (
            <div className="hidden md:flex items-center gap-2 text-xs font-mono">
              {kpiCards.map(card => (
                <span key={card.label} className={`px-2.5 py-1 rounded ${card.bg} ${card.text} border ${card.border} font-semibold`}>
                  {card.label}: {card.value}
                </span>
              ))}
            </div>
          )}

          <button
            type="button"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold transition-all"
            style={{ background: "#1d2537", border: "1px solid #f59e0b50", color: "#f59e0b" }}
          >
            <span>{isOpen ? t.collapseDashboard : t.expandDashboard}</span>
            {isOpen ? <ChevronUp size={15} /> : <ChevronDown size={15} />}
          </button>
        </div>
      </div>

      {isOpen && (
        <div className="p-5 space-y-5" style={{ background: "#0b0f17" }}>
          {/* Row 1: Status KPI Cards + Gauge */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3.5">
            {/* Total Incidents */}
            <div className="rounded-2xl p-4 relative overflow-hidden flex flex-col justify-center items-center shadow-lg" style={{ background: "#e61919", boxShadow: "0 8px 32px 0 #ef444430" }}>
              <div className="absolute inset-0 opacity-10" style={{ background: "radial-gradient(circle at 70% 30%, #fff 0%, transparent 60%)" }} />
              <div className="text-3xl sm:text-4xl font-extrabold tracking-tight mb-0.5 text-white relative z-10">{totalCount}</div>
              <div className="text-xs sm:text-sm font-semibold tracking-wide text-center leading-tight text-white/90 relative z-10">{t.totalIncidents}</div>
            </div>

            {/* New Incidents */}
            <div className="rounded-2xl p-4 relative overflow-hidden flex flex-col justify-center items-center shadow-lg" style={{ background: "#00a859", boxShadow: "0 8px 32px 0 #22c55e30" }}>
              <div className="absolute inset-0 opacity-10" style={{ background: "radial-gradient(circle at 70% 30%, #fff 0%, transparent 60%)" }} />
              <div className="text-3xl sm:text-4xl font-extrabold tracking-tight mb-0.5 text-white relative z-10">{newCount}</div>
              <div className="text-xs sm:text-sm font-semibold tracking-wide text-center leading-tight text-white/90 relative z-10">{t.newIncidents}</div>
            </div>

            {/* Pending */}
            <div className="rounded-2xl p-4 relative overflow-hidden flex flex-col justify-center items-center shadow-lg" style={{ background: "#b45309", boxShadow: "0 8px 32px 0 #f59e0b30" }}>
              <div className="absolute inset-0 opacity-10" style={{ background: "radial-gradient(circle at 70% 30%, #fff 0%, transparent 60%)" }} />
              <div className="text-3xl sm:text-4xl font-extrabold tracking-tight mb-0.5 text-white relative z-10">{pendingCount}</div>
              <div className="text-xs sm:text-sm font-semibold tracking-wide text-center leading-tight text-white/90 relative z-10">{t.pendingIncidents}</div>
            </div>

            {/* Critical */}
            <div className="rounded-2xl p-4 relative overflow-hidden flex flex-col justify-center items-center shadow-lg" style={{ background: "#7c3aed", boxShadow: "0 8px 32px 0 #7c3aed30" }}>
              <div className="absolute inset-0 opacity-10" style={{ background: "radial-gradient(circle at 70% 30%, #fff 0%, transparent 60%)" }} />
              <div className="text-3xl sm:text-4xl font-extrabold tracking-tight mb-0.5 text-white relative z-10">{criticalCount}</div>
              <div className="text-xs sm:text-sm font-semibold tracking-wide text-center leading-tight text-white/90 relative z-10">{t.criticalIncidents}</div>
            </div>

            {/* Gauge */}
            <div className="col-span-2 sm:col-span-1 rounded-2xl p-3 flex flex-col justify-center items-center shadow-md" style={{ background: "#131824", border: "1px solid #242e42" }}>
              <IncidentLevelGauge criticalCount={criticalCount} highCount={highCount} lang={lang} />
            </div>
          </div>

          {/* Row 2: Charts + Right stats */}
          <div className="grid grid-cols-1 lg:grid-cols-[210px_1fr_220px] gap-4 items-stretch">
            {/* Left: Donut Charts */}
            <div className="flex flex-col gap-4">
              <div className="rounded-2xl p-3.5 flex flex-col items-center justify-between flex-1" style={{ background: "#121622", border: "1px solid #202738" }}>
                <div className="text-xs font-bold text-slate-100 tracking-wide text-center mb-1">{t.incidentType}</div>
                <div className="relative w-[130px] h-[130px] flex items-center justify-center">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={incidentTypeData.length > 0 ? incidentTypeData : [{ name: "None", value: 100, color: "#334155" }]}
                        dataKey="value" innerRadius={38} outerRadius={58} paddingAngle={3} stroke="none"
                      >
                        {(incidentTypeData.length > 0 ? incidentTypeData : [{ name: "None", color: "#334155" }]).map((entry, index) => (
                          <Cell key={`cell-type-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip
                        formatter={(val, name) => [`${val}%`, name]}
                        contentStyle={{ background: "#0b0f17", border: "1px solid #283348", fontSize: 11, borderRadius: 6 }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <span className="text-[10px] font-bold text-slate-400">TYPE</span>
                  </div>
                </div>
                <div className="grid grid-cols-1 gap-1 w-full mt-2 text-[10px] text-slate-400">
                  {incidentTypeData.map((item) => (
                    <div key={item.name} className="flex items-center justify-between gap-1">
                      <div className="flex items-center gap-1.5 min-w-0">
                        <span className="w-2 h-2 rounded-sm shrink-0" style={{ background: item.color }} />
                        <span className="truncate text-[9px]">{item.label}</span>
                      </div>
                      <strong className="text-slate-200 shrink-0 font-mono text-[10px]">{item.value}%</strong>
                    </div>
                  ))}
                  {incidentTypeData.length === 0 && (
                    <div className="text-center text-slate-600 text-[10px]">No data</div>
                  )}
                </div>
              </div>

              <div className="rounded-2xl p-3.5 flex flex-col items-center justify-between flex-1" style={{ background: "#121622", border: "1px solid #202738" }}>
                <div className="text-xs font-bold text-slate-100 tracking-wide text-center mb-1">{t.allStatuses}</div>
                <div className="relative w-[130px] h-[130px] flex items-center justify-center">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={incidentStatusData.length > 0 ? incidentStatusData : [{ name: "None", value: 100, color: "#334155" }]}
                        dataKey="value" innerRadius={38} outerRadius={58} paddingAngle={3} stroke="none"
                      >
                        {(incidentStatusData.length > 0 ? incidentStatusData : [{ name: "None", color: "#334155" }]).map((entry, index) => (
                          <Cell key={`cell-status-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip
                        formatter={(val, name) => [`${val}%`, name]}
                        contentStyle={{ background: "#0b0f17", border: "1px solid #283348", fontSize: 11, borderRadius: 6 }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <span className="text-[10px] font-bold text-slate-400">STATUS</span>
                  </div>
                </div>
                <div className="grid grid-cols-1 gap-1 w-full mt-2 text-[10px] text-slate-400">
                  {incidentStatusData.map((item) => (
                    <div key={item.name} className="flex items-center justify-between gap-1">
                      <div className="flex items-center gap-1.5 min-w-0">
                        <span className="w-2 h-2 rounded-sm shrink-0" style={{ background: item.color }} />
                        <span className="truncate">{item.label}</span>
                      </div>
                      <strong className="text-slate-200 shrink-0 font-mono">{item.value}%</strong>
                    </div>
                  ))}
                  {incidentStatusData.length === 0 && (
                    <div className="text-center text-slate-600 text-[10px]">No data</div>
                  )}
                </div>
              </div>
            </div>

            {/* Center: Monthly Line Chart */}
            <div className="rounded-2xl p-4 flex flex-col justify-between relative overflow-hidden" style={{ background: "#121622", border: "1px solid #202738" }}>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-[#00a8ff] inline-block shadow-sm shadow-sky-500/50" />
                  <h3 className="text-base sm:text-lg font-bold text-slate-100 tracking-wide">{t.incidentsPerMonth}</h3>
                </div>
                <div className="flex items-center gap-2 px-2.5 py-1 rounded-full text-xs text-slate-300 shadow-sm" style={{ background: "#182030", border: "1px solid #2d3a52" }}>
                  <div className="w-5 h-5 rounded-full bg-amber-500 flex items-center justify-center text-[#0a0d13] font-bold text-[10px]">👔</div>
                  <span className="text-[11px] font-semibold text-slate-300">{t.safetyReview}</span>
                </div>
              </div>
              <div className="h-[280px] w-full mt-2">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={monthlyData} margin={{ top: 25, right: 20, left: -10, bottom: 0 }}>
                    <CartesianGrid stroke="#1e2638" strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="month" stroke="#8290a8" fontSize={11} tickLine={false} axisLine={{ stroke: "#242e42" }} />
                    <YAxis stroke="#8290a8" fontSize={11} allowDecimals={false} tickLine={false} axisLine={{ stroke: "#242e42" }} />
                    <Tooltip
                      formatter={(val) => [`${val} Incidents`, "Count"]}
                      contentStyle={{ background: "#0b0f17", border: "1px solid #2d3b54", fontSize: 12, borderRadius: 6 }}
                    />
                    <Line
                      type="monotone" dataKey="incidents" stroke="#00a8ff" strokeWidth={3.5}
                      dot={{ fill: "#0b0f17", stroke: "#00a8ff", strokeWidth: 3, r: 4.5 }}
                      activeDot={{ r: 7, fill: "#38bdf8", stroke: "#ffffff", strokeWidth: 2 }}
                    >
                      <LabelList dataKey="incidents" position="top" offset={9} fill="#cbd5e1" fontSize={11} fontWeight="bold" />
                    </Line>
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Right: Stats Cards */}
            <div className="flex flex-col gap-3.5 justify-between">
              {/* Closed Incidents */}
              <div className="rounded-2xl p-4 flex flex-col justify-center items-center shadow-lg flex-1 min-h-[95px] relative overflow-hidden" style={{ background: "linear-gradient(135deg, #0e7490 0%, #0369a1 100%)", boxShadow: "0 8px 24px 0 #0369a130" }}>
                <div className="absolute inset-0 opacity-10" style={{ background: "radial-gradient(circle at 80% 20%, #fff, transparent)" }} />
                <div className="text-3xl sm:text-4xl font-extrabold tracking-tight leading-none mb-1 text-white relative z-10">{closedCount}</div>
                <div className="text-xs sm:text-sm font-semibold tracking-wide text-center leading-tight text-sky-100 relative z-10">{t.closedIncidents}</div>
              </div>

              {/* Resolution Rate */}
              <div className="rounded-2xl p-4 flex flex-col justify-center items-center shadow-lg flex-1 min-h-[95px] relative overflow-hidden" style={{ background: "linear-gradient(135deg, #7042f4 0%, #5925dc 100%)", boxShadow: "0 8px 24px 0 #7042f430" }}>
                <div className="absolute inset-0 opacity-10" style={{ background: "radial-gradient(circle at 80% 20%, #fff, transparent)" }} />
                <div className="text-3xl sm:text-4xl font-extrabold tracking-tight leading-none mb-1 text-white relative z-10">{resolutionRate}%</div>
                <div className="text-xs sm:text-sm font-semibold tracking-wide text-center leading-tight text-purple-100 relative z-10">{t.resolutionRate}</div>
              </div>

              {/* Employee Satisfaction */}
              <div className="rounded-2xl p-4 flex flex-col justify-center items-center shadow-lg flex-1 min-h-[95px] relative overflow-hidden" style={{ background: "linear-gradient(135deg, #059669 0%, #047857 100%)", boxShadow: "0 8px 24px 0 #05966930" }}>
                <div className="absolute inset-0 opacity-10" style={{ background: "radial-gradient(circle at 80% 20%, #fff, transparent)" }} />
                <div className="text-3xl sm:text-4xl font-extrabold tracking-tight leading-none mb-1 text-white relative z-10">{employeeSat}%</div>
                <div className="text-xs sm:text-sm font-semibold tracking-wide text-center leading-tight text-emerald-100 relative z-10">{t.employeeSatisfaction}</div>
              </div>

              {/* Reporter Satisfaction */}
              <div className="rounded-2xl p-4 flex flex-col justify-center items-center shadow-lg flex-1 min-h-[95px] relative overflow-hidden" style={{ background: "linear-gradient(135deg, #db2777 0%, #be185d 100%)", boxShadow: "0 8px 24px 0 #db277730" }}>
                <div className="absolute inset-0 opacity-10" style={{ background: "radial-gradient(circle at 80% 20%, #fff, transparent)" }} />
                <div className="text-3xl sm:text-4xl font-extrabold tracking-tight leading-none mb-1 text-white relative z-10">{reporterSat}%</div>
                <div className="text-xs sm:text-sm font-semibold tracking-wide text-center leading-tight text-pink-100 relative z-10">{t.reporterSatisfaction}</div>
              </div>
            </div>
          </div>

          {/* Dashed bottom accent */}
          <div className="h-0.5 w-full rounded-full opacity-30" style={{ background: "repeating-linear-gradient(90deg, #f59e0b 0px, #f59e0b 12px, transparent 12px, transparent 20px)" }} />
        </div>
      )}

      {/* Bottom dashed accent line */}
      <div className="h-1.5 w-full" style={{ background: "repeating-linear-gradient(90deg, #f59e0b 0px, #f59e0b 18px, transparent 18px, transparent 28px)" }} />
    </div>
  );
}

/* ---------------------------------- Left Collapsible Sidebar Navigation ---------------------------------- */

function SidebarNavigation({ page, setPage, user, onLogout, collapsed, onToggleCollapse, openIncidentsCount = 0, lang = "en" }) {
  const t = I18N[lang] || I18N.en;

  const items = [
    { key: "dashboard", label: t.dashboard, icon: Activity },
    { key: "report", label: t.report, icon: FileText },
    { key: "incidents", label: t.incidents, icon: LayoutGrid, count: openIncidentsCount },
    { key: "insights", label: t.insights, icon: BarChart3 },
  ];
  if (user.role === "Super Admin") {
    items.push({ key: "team", label: t.team, icon: Users });
  }

  return (
    <aside
      className={`bg-[#0c1018] border-r border-[#1e2535] flex flex-col justify-between transition-all duration-300 z-30 select-none shrink-0 ${
        collapsed ? "w-20" : "w-64"
      }`}
    >
      <div>
        <div className={`h-16 px-4 border-b border-[#1e2535] flex items-center ${collapsed ? "justify-center" : "justify-between"}`}>
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-9 h-9 rounded-lg bg-amber-500 flex items-center justify-center shrink-0 shadow-md shadow-amber-500/20">
              <HardHat size={20} className="text-[#0a0d13]" />
            </div>
            {!collapsed && (
              <div className="min-w-0">
                <div className="text-sm font-extrabold text-slate-100 tracking-wider leading-none">NEAR MISS</div>
                <div className="text-[9px] text-slate-400 font-semibold tracking-[0.16em] mt-1">PLANT SAFETY</div>
              </div>
            )}
          </div>
          {!collapsed && (
            <button
              onClick={onToggleCollapse}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-[#192234] transition-colors"
              title="Collapse sidebar"
            >
              <PanelLeftClose size={18} />
            </button>
          )}
        </div>

        {collapsed && (
          <div className="p-2 flex justify-center border-b border-[#1e2535]">
            <button
              onClick={onToggleCollapse}
              className="p-2 rounded-lg text-slate-400 hover:text-amber-400 hover:bg-[#192234] transition-colors"
              title="Expand sidebar"
            >
              <PanelLeft size={18} />
            </button>
          </div>
        )}

        {!collapsed && (
          <div className="px-5 pt-5 pb-2 text-[10px] font-bold tracking-[0.18em] text-slate-500 uppercase">
            {t.menuNav}
          </div>
        )}

        <nav className="p-3 space-y-1.5">
          {items.map((it) => {
            const isActive = page === it.key;
            return (
              <button
                key={it.key}
                onClick={() => setPage(it.key)}
                className={`w-full flex items-center gap-3 px-3.5 py-3 rounded-lg text-xs font-bold tracking-wide transition-all group relative ${
                  isActive
                    ? "bg-[#232a3a] text-amber-400 shadow-md border-l-4 border-amber-400 font-extrabold"
                    : "text-slate-400 hover:text-slate-100 hover:bg-[#151c2a]"
                } ${collapsed ? "justify-center px-0" : ""}`}
                title={collapsed ? it.label : undefined}
              >
                <it.icon size={18} className={`shrink-0 ${isActive ? "text-amber-400" : "text-slate-400 group-hover:text-slate-200"}`} />

                {!collapsed && (
                  <span className="flex-1 text-left tracking-wider">
                    {it.label}
                  </span>
                )}

                {!collapsed && it.count !== undefined && it.count > 0 && (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                    {it.count}
                  </span>
                )}

                {collapsed && (
                  <div className="absolute left-full ml-3 px-3 py-1.5 rounded-md bg-[#1e2535] text-slate-100 text-xs font-bold whitespace-nowrap opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity shadow-xl border border-[#2e3a50] z-50">
                    {it.label}
                  </div>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      <div className="p-3 border-t border-[#1e2535] bg-[#090d14]/80">
        {!collapsed ? (
          <div className="flex items-center justify-between gap-2 p-2 rounded-lg bg-[#121722] border border-[#20283a]">
            <div className="min-w-0 flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-amber-600 to-amber-400 flex items-center justify-center font-bold text-[#0a0d13] text-xs shrink-0 shadow-sm">
                {user.name.slice(0, 2).toUpperCase()}
              </div>
              <div className="min-w-0">
                <div className="text-xs font-bold text-slate-200 truncate">{user.name}</div>
                <div className="text-[10px] text-slate-400 truncate">{user.role}</div>
              </div>
            </div>
            <button
              onClick={onLogout}
              className="p-1.5 rounded-md text-slate-400 hover:text-red-400 hover:bg-[#1a2130] transition-colors"
              title={t.signOut}
            >
              <LogOut size={16} />
            </button>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-2">
            <div
              className="w-9 h-9 rounded-full bg-gradient-to-tr from-amber-600 to-amber-400 flex items-center justify-center font-bold text-[#0a0d13] text-xs shadow-sm cursor-pointer"
              title={`${user.name} (${user.role})`}
            >
              {user.name.slice(0, 2).toUpperCase()}
            </div>
            <button
              onClick={onLogout}
              className="p-2 rounded-md text-slate-400 hover:text-red-400 hover:bg-[#1a2130] transition-colors"
              title={t.signOut}
            >
              <LogOut size={16} />
            </button>
          </div>
        )}
      </div>
    </aside>
  );
}

/* ---------------------------------- Top Header ---------------------------------- */

function TopHeader({ page, user, onLogout, sidebarCollapsed, onToggleSidebar, lang, setLang }) {
  const t = I18N[lang] || I18N.en;
  const pageTitles = {
    dashboard: t.dashboard,
    report: t.reportIncident,
    incidents: t.incidents,
    insights: t.insights,
    team: t.manageTeam,
  };

  return (
    <header className="h-16 border-b border-[#1c202c] bg-[#0a0d13]/90 backdrop-blur sticky top-0 z-20 px-4 sm:px-6 flex items-center justify-between">
      <div className="flex items-center gap-3">
        <button
          onClick={onToggleSidebar}
          className="p-2 rounded-lg bg-[#11151f] border border-[#242a3a] text-slate-400 hover:text-white hover:bg-[#182030] transition-colors"
          title={sidebarCollapsed ? "Expand sidebar" : "Collapse sidebar"}
        >
          {sidebarCollapsed ? <PanelLeft size={18} /> : <PanelLeftClose size={18} />}
        </button>

        <div>
          <div className="text-[10px] text-amber-500 font-bold tracking-widest uppercase">
            NEAR MISS SAFETY OPERATIONS
          </div>
          <div className="text-sm sm:text-base font-bold text-slate-100 leading-tight">
            {pageTitles[page] || t.dashboard}
          </div>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <div className="flex items-center bg-[#11151f] border border-[#242a3a] rounded-lg p-1">
          <Globe size={14} className="text-slate-400 mx-1.5 shrink-0" />
          {["en", "fr", "ar"].map((l) => (
            <button
              key={l}
              onClick={() => setLang(l)}
              className={`px-2 py-1 rounded text-xs font-bold uppercase transition-colors ${
                lang === l ? "bg-amber-500 text-black shadow-sm" : "text-slate-400 hover:text-slate-200"
              }`}
            >
              {l}
            </button>
          ))}
        </div>

        <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#11151f] border border-[#242a3a]">
          <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-xs text-slate-300 font-mono">{t.plantStatus}</span>
        </div>

        <div className="text-right hidden md:block">
          <div className="text-[10px] text-slate-500 tracking-wide">{t.signedInAs}</div>
          <div className="text-xs text-slate-200 font-semibold leading-none">{user.name} — <span className="text-amber-400">{user.role}</span></div>
        </div>

        <button
          onClick={onLogout}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#161c28] border border-[#263148] hover:border-red-500/40 text-slate-300 hover:text-red-300 text-xs font-semibold transition-colors"
          title={t.signOut}
        >
          <LogOut size={14} />
          <span className="hidden sm:inline">{t.signOut}</span>
        </button>
      </div>
    </header>
  );
}

/* ---------------------------------- Report Page (With Screenshot Paste & Drag/Drop) ---------------------------------- */

function ReportPage({ user, onSubmit, lang = "en" }) {
  const t = I18N[lang] || I18N.en;

  const getTodayDate = () => {
    const d = new Date();
    return d.toISOString().slice(0, 10);
  };
  const getTodayTime = () => {
    const d = new Date();
    const h = d.getHours().toString().padStart(2, "0");
    const m = d.getMinutes().toString().padStart(2, "0");
    return `${h}:${m}`;
  };

  const [title, setTitle] = useState("");
  const [dateVal, setDateVal] = useState(getTodayDate);
  const [timeVal, setTimeVal] = useState(getTodayTime);
  const [severity, setSeverity] = useState("Medium");
  const [location, setLocation] = useState(LOCATIONS[0]);
  const [type, setType] = useState(INCIDENT_TYPES[0]);
  const [description, setDescription] = useState("");
  const [files, setFiles] = useState([]);
  const [confirmation, setConfirmation] = useState(null);
  const [previewImage, setPreviewImage] = useState(null);
  const [pasteNotice, setPasteNotice] = useState(false);

  // Global Clipboard Paste listener for instant screenshots
  useEffect(() => {
    function handlePaste(e) {
      const items = e.clipboardData?.items;
      if (!items) return;
      for (let i = 0; i < items.length; i++) {
        if (items[i].type.indexOf("image") !== -1) {
          const blob = items[i].getAsFile();
          if (blob) {
            const reader = new FileReader();
            reader.onload = (evt) => {
              const newFile = {
                id: `att-paste-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
                name: `Screenshot_${new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-")}.png`,
                type: blob.type || "image/png",
                size: blob.size,
                dataUrl: evt.target.result,
                date: new Date().toISOString(),
              };
              setFiles((prev) => [newFile, ...prev]);
              setPasteNotice(true);
              setTimeout(() => setPasteNotice(false), 3000);
            };
            reader.readAsDataURL(blob);
          }
        }
      }
    }
    window.addEventListener("paste", handlePaste);
    return () => window.removeEventListener("paste", handlePaste);
  }, []);

  function handleFiles(e) {
    const selected = Array.from(e.target.files || []);
    selected.forEach((f) => {
      const reader = new FileReader();
      reader.onload = (evt) => {
        setFiles((prev) => [
          ...prev,
          {
            id: `att-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
            name: f.name,
            type: f.type || "application/octet-stream",
            size: f.size,
            dataUrl: evt.target.result,
            date: new Date().toISOString(),
          },
        ]);
      };
      reader.readAsDataURL(f);
    });
  }

  function removeFile(id) {
    setFiles((prev) => prev.filter((f) => f.id !== id));
  }

  function setNow() {
    setDateVal(getTodayDate());
    setTimeVal(getTodayTime());
  }

  function submit(e) {
    e.preventDefault();
    if (!title.trim() || !description.trim()) return;

    let isoDate;
    try {
      isoDate = new Date(`${dateVal}T${timeVal || "12:00"}:00`).toISOString();
    } catch {
      isoDate = new Date().toISOString();
    }

    const incident = onSubmit({
      title: title.trim(),
      incidentDate: isoDate,
      severity,
      location,
      type,
      description: description.trim(),
      attachments: files,
      reportedBy: user.email,
    });
    setConfirmation(incident.number);
    setTitle("");
    setDescription("");
    setFiles([]);
    setSeverity("Medium");
    setType(INCIDENT_TYPES[0]);
    setNow();
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      {previewImage && <ImageModal image={previewImage} onClose={() => setPreviewImage(null)} lang={lang} />}

      <Eyebrow>{t.newReport}</Eyebrow>
      <h1 className="text-3xl font-bold text-slate-100 tracking-tight mb-2">{t.reportIncident}</h1>
      <p className="text-sm text-slate-400 mb-6">
        {t.submittingAs} <span className="text-slate-200 font-mono">{user.email}</span>.
      </p>

      {confirmation && (
        <div className="mb-6 flex items-center gap-2 bg-green-500/10 border border-green-500/40 text-green-300 rounded-md px-4 py-3 text-sm">
          <Check size={16} /> {t.incidentSubmitted} <span className="font-mono font-semibold text-white px-1.5 py-0.5 rounded bg-green-900/50">{confirmation}</span>
        </div>
      )}

      {pasteNotice && (
        <div className="mb-4 flex items-center gap-2 bg-amber-500/20 border border-amber-500/50 text-amber-300 rounded-md px-4 py-2.5 text-xs animate-bounce">
          <ClipboardPaste size={16} /> {t.screenshotPasted}
        </div>
      )}

      <Card className="p-6 sm:p-8 shadow-xl">
        <form onSubmit={submit} className="space-y-6">
          <Field label={t.title}>
            <input className={inputCls} placeholder={t.titlePlaceholder} value={title} onChange={(e) => setTitle(e.target.value)} required />
          </Field>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Field label={t.dateIncident}>
              <div className="relative flex items-center">
                <input
                  type="date"
                  className={inputCls + " text-slate-200"}
                  value={dateVal}
                  onChange={(e) => setDateVal(e.target.value)}
                  required
                />
              </div>
            </Field>

            <Field label={t.timeIncident}>
              <div className="flex gap-2">
                <input
                  type="time"
                  className={inputCls + " text-slate-200 flex-1"}
                  value={timeVal}
                  onChange={(e) => setTimeVal(e.target.value)}
                  required
                />
                <button
                  type="button"
                  onClick={setNow}
                  className="px-3 py-2 bg-[#161c28] border border-[#2e3748] hover:border-amber-500 text-xs font-semibold text-amber-400 rounded-md transition-colors shrink-0"
                >
                  {t.now}
                </button>
              </div>
            </Field>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Field label={t.severity}>
              <select className={inputCls} value={severity} onChange={(e) => setSeverity(e.target.value)}>
                {SEVERITIES.map((s) => <option key={s} value={s}>{getSeverityLabel(s, lang)}</option>)}
              </select>
            </Field>
            <Field label={t.location}>
              <select className={inputCls} value={location} onChange={(e) => setLocation(e.target.value)}>
                {LOCATIONS.map((l) => <option key={l} value={l}>{getLocationLabel(l, lang)}</option>)}
              </select>
            </Field>
          </div>

          <Field label={t.incidentType}>
            <select className={inputCls} value={type} onChange={(e) => setType(e.target.value)}>
              {INCIDENT_TYPES.map((tItem) => <option key={tItem} value={tItem}>{getTypeLabel(tItem, lang)}</option>)}
            </select>
          </Field>

          <Field label={t.description}>
            <textarea rows={5} className={inputCls} placeholder={t.descPlaceholder} value={description} onChange={(e) => setDescription(e.target.value)} required />
          </Field>

          {/* Attachment Upload + Screenshot Paste Action */}
          <Field label={t.attachments}>
            <div className="space-y-3">
              <label className="flex flex-col items-center justify-center border-2 border-dashed border-[#2b3140] hover:border-amber-500/60 rounded-xl p-6 text-sm text-slate-400 cursor-pointer bg-[#0c1018] hover:bg-[#121722] transition-all">
                <Paperclip size={24} className="text-amber-400 mb-2" />
                <span className="font-semibold text-slate-200">{t.attachPrompt}</span>
                <span className="text-xs text-slate-500 mt-1">PNG, JPG, WEBP, PDF (Max 10MB)</span>
                <input type="file" accept="image/*,.pdf,.doc,.docx" multiple className="hidden" onChange={handleFiles} />
              </label>

              <div className="flex items-center justify-between text-xs text-slate-400 bg-[#0c1018] px-3.5 py-2 rounded-lg border border-[#20283a]">
                <div className="flex items-center gap-2">
                  <ClipboardPaste size={15} className="text-amber-400" />
                  <span>{t.pasteHint}</span>
                </div>
              </div>
            </div>

            {files.length > 0 && (
              <div className="mt-4 grid grid-cols-2 sm:grid-cols-3 gap-3">
                {files.map((f) => {
                  const isImg = f.type?.startsWith("image/") || (f.dataUrl && f.dataUrl.startsWith("data:image"));
                  return (
                    <div key={f.id} className="relative group bg-[#090d14] border border-[#222a3a] rounded-lg p-2.5 flex flex-col justify-between">
                      {isImg ? (
                        <div
                          onClick={() => setPreviewImage(f)}
                          className="relative h-24 rounded overflow-hidden bg-black/40 mb-2 cursor-pointer flex items-center justify-center"
                        >
                          <img src={f.dataUrl} alt={f.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                          <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity text-white text-xs gap-1">
                            <Eye size={14} /> {t.viewPhoto}
                          </div>
                        </div>
                      ) : (
                        <div className="h-24 rounded bg-[#131824] mb-2 flex items-center justify-center text-slate-500">
                          <FileText size={32} />
                        </div>
                      )}
                      <div className="flex items-center justify-between text-xs text-slate-300">
                        <span className="truncate flex-1 font-medium">{f.name}</span>
                        <button
                          type="button"
                          onClick={() => removeFile(f.id)}
                          className="p-1 rounded text-red-400 hover:bg-red-500/20 ml-1 transition-colors"
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>
                      <span className="text-[10px] text-slate-500 font-mono mt-0.5">{Math.round(f.size / 1024)} KB</span>
                    </div>
                  );
                })}
              </div>
            )}
          </Field>

          <button type="submit" className="w-full sm:w-auto flex items-center justify-center gap-2 bg-amber-500 hover:bg-amber-400 text-[#0a0d13] font-bold rounded-lg px-8 py-3.5 text-sm tracking-wide transition-colors shadow-lg shadow-amber-500/20">
            <Send size={16} /> {t.submitIncident}
          </button>
        </form>
      </Card>
    </div>
  );
}

/* ---------------------------------- Dedicated Dashboard Page ---------------------------------- */

function DashboardPage({ incidents, user, lang = "en" }) {
  const t = I18N[lang] || I18N.en;
  const scoped = visibleIncidents(incidents, user);

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <Eyebrow>{user.role === "Super Admin" ? "ADMIN OVERVIEW" : `${user.role} OVERVIEW`}</Eyebrow>
      <h1 className="text-3xl font-bold text-slate-100 tracking-tight mb-1">{t.kpiDashboard}</h1>
      <p className="text-sm text-slate-400 mb-6">{t.kpiSubtitle}</p>

      <IncidentKPIDashboard incidents={scoped} defaultOpen={true} lang={lang} />
    </div>
  );
}

/* ---------------------------------- Incidents List Page ---------------------------------- */

function visibleIncidents(incidents, user) {
  if (user.role === "Super Admin") return incidents;
  if (user.role === "Employee") return incidents.filter((i) => i.reportedBy === user.email);
  return incidents.filter((i) => i.assignments.some((a) => a.department === user.department));
}

function IncidentsPage({ incidents, user, onOpen, lang = "en" }) {
  const t = I18N[lang] || I18N.en;
  const [q, setQ] = useState("");
  const [typeFilter, setTypeFilter] = useState("All");
  const [sevFilter, setSevFilter] = useState("All");
  const [statusFilter, setStatusFilter] = useState("All");
  const [sort, setSort] = useState("newest");
  const [pageNum, setPageNum] = useState(1);
  const perPage = 8;

  const scoped = visibleIncidents(incidents, user);
  const filtered = scoped.filter((i) => {
    if (typeFilter !== "All" && i.type !== typeFilter) return false;
    if (sevFilter !== "All" && i.severity !== sevFilter) return false;
    if (statusFilter !== "All" && i.status !== statusFilter) return false;
    if (q.trim()) {
      const s = q.toLowerCase();
      if (!i.number?.toLowerCase().includes(s) && !i.title?.toLowerCase().includes(s) && !i.location?.toLowerCase().includes(s)) return false;
    }
    return true;
  }).sort((a, b) => sort === "newest" ? new Date(b.incidentDate) - new Date(a.incidentDate) : new Date(a.incidentDate) - new Date(b.incidentDate));

  const totalPages = Math.max(1, Math.ceil(filtered.length / perPage));
  const shown = filtered.slice((pageNum - 1) * perPage, pageNum * perPage);
  const openCount = scoped.filter((i) => i.status !== "Closed" && i.status !== "Resolved").length;

  const selectCls = "bg-[#11151f] border border-[#242a3a] rounded-md px-3 py-2 text-sm text-slate-300 focus:outline-none focus:ring-1 focus:ring-amber-500/60";

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="flex items-center justify-between flex-wrap gap-3 mb-2">
        <div>
          <Eyebrow>{user.role === "Super Admin" ? "ADMIN REGISTRY" : `${user.role} REGISTRY`}</Eyebrow>
          <h1 className="text-3xl font-bold text-slate-100 tracking-tight">{t.incidents}</h1>
        </div>
      </div>

      <p className="text-sm text-slate-400 mb-5">
        {user.role === "Super Admin" ? "Full access to every incident on site." : user.role === "Employee" ? "Incidents you have reported." : `Incidents assigned to ${user.department}.`}
      </p>

      <div className="flex flex-wrap gap-2 mb-4">
        <div className="relative flex-1 min-w-[220px]">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input className={inputCls + " pl-9"} placeholder={t.searchPlaceholder} value={q} onChange={(e) => { setQ(e.target.value); setPageNum(1); }} />
        </div>
        <select className={selectCls} value={typeFilter} onChange={(e) => { setTypeFilter(e.target.value); setPageNum(1); }}>
          <option value="All">{t.allTypes}</option>
          {INCIDENT_TYPES.map((tItem) => <option key={tItem} value={tItem}>{getTypeLabel(tItem, lang)}</option>)}
        </select>
        <select className={selectCls} value={sevFilter} onChange={(e) => { setSevFilter(e.target.value); setPageNum(1); }}>
          <option value="All">{t.allSeverities}</option>
          {SEVERITIES.map((s) => <option key={s} value={s}>{getSeverityLabel(s, lang)}</option>)}
        </select>
        <select className={selectCls} value={statusFilter} onChange={(e) => { setStatusFilter(e.target.value); setPageNum(1); }}>
          <option value="All">{t.allStatuses}</option>
          {STATUSES.map((s) => <option key={s} value={s}>{getStatusLabel(s, lang)}</option>)}
        </select>
        <select className={selectCls} value={sort} onChange={(e) => setSort(e.target.value)}>
          <option value="newest">{t.newestFirst}</option>
          <option value="oldest">{t.oldestFirst}</option>
        </select>
      </div>

      <div className="text-xs text-slate-500 mb-3 tracking-wide flex items-center justify-between">
        <span>{filtered.length} INCIDENT{filtered.length !== 1 ? "S" : ""} · {openCount} {t.openFilterCount}</span>
        <span className="text-slate-400 text-[11px]">{t.clickPhotoView}</span>
      </div>

      <div className="space-y-3">
        {shown.length === 0 && <Card className="p-8 text-center text-sm text-slate-500">{t.noIncidents}</Card>}
        {shown.map((i) => (
          <div
            key={i.id}
            onClick={() => onOpen(i.id)}
            className="group bg-[#11151f] hover:bg-[#141a27] border border-[#242a3a] hover:border-amber-500/60 rounded-xl p-4 transition-all duration-200 cursor-pointer shadow-sm hover:shadow-lg hover:shadow-amber-500/5 select-none"
          >
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 flex-wrap mb-2">
                  <span className="text-xs font-mono font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/30">
                    {i.number}
                  </span>
                  <SeverityBadge severity={i.severity} lang={lang} />
                  <StatusBadge status={i.status} lang={lang} />
                  <TypeBadge type={i.type} lang={lang} />
                  {i.attachments && i.attachments.length > 0 && (
                    <span className="inline-flex items-center gap-1 text-[11px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/30 font-semibold">
                      <ImageIcon size={12} /> {i.attachments.length} {i.attachments.length === 1 ? "photo" : "photos"}
                    </span>
                  )}
                </div>
                <div className="text-base font-bold text-slate-100 group-hover:text-amber-400 transition-colors truncate">
                  {i.title}
                </div>
                <div className="text-xs text-slate-400 mt-1 flex items-center gap-2 flex-wrap">
                  <span className="text-slate-300 font-medium">{getLocationLabel(i.location, lang)}</span>
                  <span>·</span>
                  <span>{fmtDate(i.incidentDate, lang)}</span>
                  <span>·</span>
                  <span>{t.reportedBy}: <strong className="text-slate-300 font-normal">{i.reportedBy}</strong></span>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0 mt-1">
                <span className="hidden sm:inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-300 group-hover:text-amber-400 bg-[#161c28] group-hover:bg-amber-500/10 border border-[#263148] group-hover:border-amber-500/40 transition-all">
                  <Eye size={13} /> {t.viewDetailBtn}
                </span>
                <ChevronRight size={18} className="text-slate-500 group-hover:text-amber-400 transition-colors" />
              </div>
            </div>
          </div>
        ))}
      </div>

      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-2 mt-6">
          <button disabled={pageNum === 1} onClick={() => setPageNum((p) => p - 1)} className="px-3 py-1.5 text-xs rounded border border-[#242a3a] text-slate-400 disabled:opacity-30">
            {t.prev}
          </button>
          <span className="text-xs text-slate-500">
            {lang === "ar" ? `صفحة ${pageNum} من ${totalPages}` : lang === "fr" ? `Page ${pageNum} sur ${totalPages}` : `Page ${pageNum} of ${totalPages}`}
          </span>
          <button disabled={pageNum === totalPages} onClick={() => setPageNum((p) => p + 1)} className="px-3 py-1.5 text-xs rounded border border-[#242a3a] text-slate-400 disabled:opacity-30">
            {t.next}
          </button>
        </div>
      )}
    </div>
  );
}

/* ---------------------------------- Incident Detail View (With Image Previews, Follow-up Attachment & Lightbox) ---------------------------------- */

function IncidentDetailPage({ incident, user, onBack, onUpdateAssignment, onAddComment, onCloseIncident, onSaveInvestigation, onAddAttachment, lang = "en" }) {
  const t = I18N[lang] || I18N.en;
  const [commentText, setCommentText] = useState("");
  const [selectedPhoto, setSelectedPhoto] = useState(null);
  const [pasteNotice, setPasteNotice] = useState(false);
  const fileInputRef = useRef(null);

  if (!incident) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-12 text-center">
        <p className="text-slate-400 mb-4">Incident not found or no longer available.</p>
        <button onClick={onBack} className="px-4 py-2 bg-amber-500 text-black font-bold rounded-lg text-xs">
          {t.backToIncidents}
        </button>
      </div>
    );
  }

  const assignments = incident.assignments || [];
  const attachments = incident.attachments || [];
  const comments = incident.comments || [];
  const investigation = incident.investigation || {};
  const auditLog = incident.auditLog || [];

  const canManage = (dept) => user.role === "Super Admin" || user.department === dept;
  const canCloseNow = user.role === "Super Admin" && incident.status === "Resolved";

  // Clipboard Paste for adding screenshots directly to this incident
  useEffect(() => {
    function handlePaste(e) {
      const items = e.clipboardData?.items;
      if (!items) return;
      for (let i = 0; i < items.length; i++) {
        if (items[i].type.indexOf("image") !== -1) {
          const blob = items[i].getAsFile();
          if (blob) {
            const reader = new FileReader();
            reader.onload = (evt) => {
              const newAttachment = {
                id: `att-paste-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
                name: `Evidence_${new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-")}.png`,
                type: blob.type || "image/png",
                size: blob.size,
                dataUrl: evt.target.result,
                date: new Date().toISOString(),
              };
              if (onAddAttachment) {
                onAddAttachment(incident.id, newAttachment);
                setPasteNotice(true);
                setTimeout(() => setPasteNotice(false), 3000);
              }
            };
            reader.readAsDataURL(blob);
          }
        }
      }
    }
    window.addEventListener("paste", handlePaste);
    return () => window.removeEventListener("paste", handlePaste);
  }, [incident.id, onAddAttachment]);

  function handleFileSelect(e) {
    const selected = Array.from(e.target.files || []);
    selected.forEach((f) => {
      const reader = new FileReader();
      reader.onload = (evt) => {
        const newAttachment = {
          id: `att-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
          name: f.name,
          type: f.type || "application/octet-stream",
          size: f.size,
          dataUrl: evt.target.result,
          date: new Date().toISOString(),
        };
        if (onAddAttachment) {
          onAddAttachment(incident.id, newAttachment);
        }
      };
      reader.readAsDataURL(f);
    });
  }

  function submitComment(e) {
    e.preventDefault();
    if (!commentText.trim()) return;
    onAddComment(incident.id, commentText.trim());
    setCommentText("");
  }

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      {selectedPhoto && <ImageModal image={selectedPhoto} onClose={() => setSelectedPhoto(null)} lang={lang} />}

      <button
        onClick={onBack}
        className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#141a27] border border-[#263148] text-xs font-semibold text-slate-300 hover:text-amber-400 hover:border-amber-500/40 mb-5 transition-colors"
      >
        {t.backToIncidents}
      </button>

      {pasteNotice && (
        <div className="mb-4 flex items-center gap-2 bg-amber-500/20 border border-amber-500/50 text-amber-300 rounded-md px-4 py-2.5 text-xs animate-bounce">
          <ClipboardPaste size={16} /> {t.screenshotPasted}
        </div>
      )}

      <div className="flex items-start justify-between flex-wrap gap-3 mb-3">
        <div>
          <div className="text-sm font-mono font-bold text-amber-400 mb-1">{incident.number}</div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-100">{incident.title}</h1>
        </div>
        {canCloseNow && (
          <button onClick={() => onCloseIncident(incident.id)} className="bg-amber-500 hover:bg-amber-400 text-[#0a0d13] text-xs font-bold rounded-md px-4 py-2 tracking-wide shadow-md">
            {t.markClosed}
          </button>
        )}
      </div>

      <div className="flex items-center gap-2 flex-wrap mb-6">
        <SeverityBadge severity={incident.severity} lang={lang} />
        <StatusBadge status={incident.status} lang={lang} />
        <TypeBadge type={incident.type} lang={lang} />
        <span className="text-xs text-slate-400 font-medium">📍 {getLocationLabel(incident.location, lang)}</span>
        <span className="text-xs text-slate-400">· {t.reportedBy}: <strong className="text-slate-300 font-normal">{incident.reportedBy}</strong></span>
        <span className="text-xs text-slate-400">· {fmtDate(incident.incidentDate, lang)}</span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_300px] gap-6">
        <div className="space-y-6">
          <Card className="p-5">
            <div className="text-[11px] tracking-[0.15em] text-slate-500 font-semibold mb-2 uppercase">{t.description}</div>
            <p className="text-sm text-slate-300 leading-relaxed whitespace-pre-wrap">{incident.description || "No description provided."}</p>
          </Card>

          {/* Photo Gallery & Attachments + Screenshot Upload */}
          <Card className="p-5">
            <div className="text-[11px] tracking-[0.15em] text-slate-500 font-semibold mb-3 flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <ImageIcon size={14} className="text-amber-400" />
                <span className="uppercase">{t.attachments} ({attachments.length})</span>
              </div>
              <div className="flex items-center gap-2">
                <input type="file" ref={fileInputRef} accept="image/*,.pdf,.doc,.docx" multiple className="hidden" onChange={handleFileSelect} />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="flex items-center gap-1 px-2.5 py-1 rounded bg-[#182030] border border-[#2d3a52] text-[11px] font-semibold text-amber-400 hover:bg-[#20293d] transition-colors"
                >
                  <Plus size={13} /> {t.addMorePhotos}
                </button>
              </div>
            </div>

            {attachments.length === 0 ? (
              <div className="text-sm text-slate-500 py-3 flex items-center justify-between flex-wrap gap-2">
                <span>{t.noAttachments}</span>
                <span className="text-xs text-amber-400/80 font-mono">{t.pasteHint}</span>
              </div>
            ) : (
              <div className="space-y-2">
                <div className="text-[11px] text-slate-400 mb-2">{t.clickPhotoView}</div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
                  {attachments.map((f, i) => {
                    const isImg = (f.type && f.type.startsWith("image/")) || (f.dataUrl && f.dataUrl.startsWith("data:image")) || (f.url && (f.url.endsWith(".jpg") || f.url.endsWith(".png") || f.url.endsWith(".svg")));
                    return (
                      <div
                        key={f.id || i}
                        className="bg-[#090d14] border border-[#222a3c] hover:border-amber-500/60 rounded-xl p-2.5 flex flex-col justify-between group transition-all"
                      >
                        {isImg ? (
                          <div
                            onClick={() => setSelectedPhoto(f)}
                            className="relative h-36 rounded-lg overflow-hidden bg-black/60 mb-2 cursor-pointer flex items-center justify-center border border-[#1b2234]"
                          >
                            <img
                              src={f.dataUrl || f.url}
                              alt={f.name || "Incident Attachment"}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                            />
                            <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity text-white text-xs font-semibold gap-1.5 backdrop-blur-[2px]">
                              <Eye size={16} className="text-amber-400" /> {t.viewPhoto}
                            </div>
                          </div>
                        ) : (
                          <div className="h-36 rounded-lg bg-[#131824] mb-2 flex flex-col items-center justify-center text-slate-400 gap-1 border border-[#1b2234]">
                            <FileText size={36} className="text-amber-400/80" />
                            <span className="text-[10px] text-slate-500 font-mono">DOCUMENT</span>
                          </div>
                        )}
                        <div>
                          <div className="text-xs text-slate-200 truncate font-semibold">{f.name || `Attachment #${i + 1}`}</div>
                          <div className="flex items-center justify-between text-[10px] text-slate-500 font-mono mt-1">
                            <span>{f.size ? `${Math.round(f.size / 1024)} KB` : "File"}</span>
                            {isImg && (
                              <button
                                type="button"
                                onClick={() => setSelectedPhoto(f)}
                                className="text-amber-400 hover:underline flex items-center gap-0.5"
                              >
                                <Eye size={10} /> View
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </Card>

          <Card className="p-5">
            <div className="text-[11px] tracking-[0.15em] text-slate-500 font-semibold mb-3 uppercase">{t.investigation}</div>
            <div className="space-y-4">
              {assignments.map((a) => (
                <InvestigationBlock
                  key={a.department}
                  assignment={a}
                  investigation={investigation[a.department]}
                  editable={canManage(a.department)}
                  onSave={(data) => onSaveInvestigation(incident.id, a.department, data)}
                  lang={lang}
                />
              ))}
            </div>
          </Card>

          <Card className="p-5">
            <div className="text-[11px] tracking-[0.15em] text-slate-500 font-semibold mb-3 uppercase">{t.comments}</div>
            <div className="space-y-4 mb-4">
              {comments.length === 0 && <div className="text-sm text-slate-500">{t.noComments}</div>}
              {comments.map((c, i) => (
                <div key={i} className="border-l-2 border-[#242a3a] pl-3">
                  <div className="text-xs text-slate-500 mb-0.5">{fmtDate(c.date, lang)} · <span className="text-slate-300 font-medium">{c.department ? `${c.department} - ` : ""}{c.author}</span></div>
                  <div className="text-sm text-slate-300">{c.text}</div>
                </div>
              ))}
            </div>
            <form onSubmit={submitComment} className="flex gap-2">
              <input className={inputCls} placeholder={t.addComment} value={commentText} onChange={(e) => setCommentText(e.target.value)} />
              <button type="submit" className="bg-amber-500 hover:bg-amber-400 text-[#0a0d13] rounded-md px-4 text-sm font-semibold shrink-0">{t.post}</button>
            </form>
          </Card>

          {user.role === "Super Admin" && (
            <Card className="p-5">
              <div className="text-[11px] tracking-[0.15em] text-slate-500 font-semibold mb-3 uppercase">{t.activityHistory}</div>
              <div className="space-y-2">
                {auditLog.map((a, i) => (
                  <div key={i} className="text-xs text-slate-500 flex gap-2">
                    <Clock size={12} className="mt-0.5 shrink-0" />
                    <span><span className="text-slate-300">{formatAuditAction(a.action, lang)}</span> — {a.user} · {fmtDate(a.date, lang)}</span>
                  </div>
                ))}
              </div>
            </Card>
          )}
        </div>

        <div>
          <Card className="p-5">
            <div className="text-[11px] tracking-[0.15em] text-slate-500 font-semibold mb-3 uppercase">{t.responsibleDept}</div>
            <div className="space-y-3">
              {assignments.map((a) => (
                <div key={a.department} className="bg-[#0d1119] border border-[#242a3a] rounded-md p-3">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-semibold text-slate-200">{a.department}</span>
                    <StatusBadge status={a.status} lang={lang} />
                  </div>
                  {canManage(a.department) && a.status !== "Closed" && (
                    <select
                      className="w-full bg-[#11151f] border border-[#242a3a] rounded px-2 py-1.5 text-xs text-slate-300"
                      value={a.status}
                      onChange={(e) => onUpdateAssignment(incident.id, a.department, e.target.value)}
                    >
                      {STATUSES.filter((s) => s !== "Closed").map((s) => <option key={s} value={s}>{getStatusLabel(s, lang)}</option>)}
                    </select>
                  )}
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

function InvestigationBlock({ assignment, investigation, editable, onSave, lang = "en" }) {
  const t = I18N[lang] || I18N.en;
  const [open, setOpen] = useState(false);
  const [data, setData] = useState(investigation || { rootCause: "", immediateAction: "", correctiveAction: "", preventiveAction: "", responsiblePerson: "", targetDate: "" });

  useEffect(() => { setData(investigation || { rootCause: "", immediateAction: "", correctiveAction: "", preventiveAction: "", responsiblePerson: "", targetDate: "" }); }, [investigation]);

  const hasData = investigation && (investigation.rootCause || investigation.correctiveAction);

  return (
    <div className="border border-[#242a3a] rounded-md p-3">
      <div className="flex items-center justify-between">
        <span className="text-sm font-semibold text-slate-200">{assignment.department}</span>
        {editable && <button onClick={() => setOpen((o) => !o)} className="text-xs text-amber-400">{open ? t.close : hasData ? t.edit : t.addNotes}</button>}
      </div>
      {!open && hasData && (
        <div className="mt-2 text-xs text-slate-400 space-y-1">
          <div><span className="text-slate-500">{t.rootCause}:</span> {investigation.rootCause}</div>
          <div><span className="text-slate-500">{t.correctiveAction}:</span> {investigation.correctiveAction}</div>
        </div>
      )}
      {!open && !hasData && <div className="mt-1 text-xs text-slate-600">{t.noInvestigation}</div>}
      {open && (
        <div className="mt-3 space-y-2">
          {[
            ["rootCause", t.rootCause], ["immediateAction", t.immediateAction],
            ["correctiveAction", t.correctiveAction], ["preventiveAction", t.preventiveAction],
            ["responsiblePerson", t.responsiblePerson],
          ].map(([key, label]) => (
            <div key={key}>
              <label className="text-[11px] text-slate-500">{label}</label>
              <input className={inputCls + " text-xs py-1.5"} value={data[key]} onChange={(e) => setData({ ...data, [key]: e.target.value })} />
            </div>
          ))}
          <div>
            <label className="text-[11px] text-slate-500">{t.targetDate}</label>
            <input type="date" className={inputCls + " text-xs py-1.5"} value={data.targetDate} onChange={(e) => setData({ ...data, targetDate: e.target.value })} />
          </div>
          <button onClick={() => { onSave(data); setOpen(false); }} className="w-full bg-amber-500 hover:bg-amber-400 text-[#0a0d13] rounded px-3 py-1.5 text-xs font-semibold mt-1">{t.saveNotes}</button>
        </div>
      )}
    </div>
  );
}

/* ---------------------------------- Insights Page ---------------------------------- */

function InsightsPage({ incidents, user, lang = "en" }) {
  const t = I18N[lang] || I18N.en;
  const scoped = visibleIncidents(incidents, user);
  const total = scoped.length;
  const counts = STATUSES.reduce((acc, s) => { acc[s] = scoped.filter((i) => i.status === s).length; return acc; }, {});

  const severityData = SEVERITIES.map((s) => ({ name: getSeverityLabel(s, lang), value: scoped.filter((i) => i.severity === s).length })).filter((d) => d.value > 0);
  const typeData = INCIDENT_TYPES.map((type) => ({ name: getTypeLabel(type, lang), value: scoped.filter((i) => i.type === type).length }));
  const deptData = DEPARTMENTS.map((d) => ({ name: d, value: scoped.filter((i) => i.assignments.some((a) => a.department === d)).length }));
  const locationData = LOCATIONS.map((l) => ({ name: getLocationLabel(l, lang), value: scoped.filter((i) => i.location === l).length })).filter((d) => d.value > 0).sort((a, b) => b.value - a.value);

  const kpi = (label, value) => (
    <Card className="p-4">
      <div className="text-[11px] tracking-[0.15em] text-slate-500 font-semibold mb-1 uppercase">{label}</div>
      <div className="text-2xl font-bold text-slate-100">{value}</div>
    </Card>
  );

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <Eyebrow>{user.role === "Super Admin" ? "ADMIN SCOPE" : `${user.role} SCOPE`}</Eyebrow>
      <h1 className="text-3xl font-bold text-slate-100 tracking-tight mb-1">{t.insights}</h1>
      <p className="text-sm text-slate-400 mb-6">{t.kpiSubtitle}</p>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
        {kpi(t.totalIncidents, total)}
        {kpi(getStatusLabel("Open", lang), counts["Open"])}
        {kpi(getStatusLabel("In Review", lang), counts["In Review"])}
        {kpi(getStatusLabel("Pending", lang), counts["Pending"])}
        {kpi(getStatusLabel("Resolved", lang), counts["Resolved"])}
        {kpi(getStatusLabel("Closed", lang), counts["Closed"])}
        {kpi(t.incidentsEscalated, scoped.filter(i => i.severity === "Critical" || i.severity === "High").length)}
        {kpi("DEPARTMENTS", deptData.filter((d) => d.value > 0).length)}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <Card className="p-5">
          <div className="text-[11px] tracking-[0.15em] text-slate-500 font-semibold mb-3 uppercase">{t.incidentsBySeverity}</div>
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie data={severityData} dataKey="value" nameKey="name" innerRadius={55} outerRadius={85} paddingAngle={2}>
                {severityData.map((d, i) => <Cell key={i} fill={["#22d3ee", "#eab308", "#f97316", "#ef4444"][i % 4]} />)}
              </Pie>
              <Tooltip contentStyle={{ background: "#11151f", border: "1px solid #242a3a", fontSize: 12 }} />
            </PieChart>
          </ResponsiveContainer>
        </Card>

        <Card className="p-5">
          <div className="text-[11px] tracking-[0.15em] text-slate-500 font-semibold mb-3 uppercase">{t.incidentsByDept}</div>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={deptData}>
              <CartesianGrid stroke="#1c202c" />
              <XAxis dataKey="name" stroke="#64748b" fontSize={12} />
              <YAxis stroke="#64748b" fontSize={11} allowDecimals={false} />
              <Tooltip contentStyle={{ background: "#11151f", border: "1px solid #242a3a", fontSize: 12 }} />
              <Bar dataKey="value" fill="#f59e0b" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>
      </div>

      <Card className="p-5">
        <div className="text-[11px] tracking-[0.15em] text-slate-500 font-semibold mb-3 uppercase">{t.hotspotsByLocation}</div>
        <ResponsiveContainer width="100%" height={Math.max(180, locationData.length * 36)}>
          <BarChart data={locationData} layout="vertical" margin={{ left: 10 }}>
            <CartesianGrid stroke="#1c202c" horizontal={false} />
            <XAxis type="number" stroke="#64748b" fontSize={11} allowDecimals={false} />
            <YAxis type="category" dataKey="name" stroke="#64748b" fontSize={11} width={140} />
            <Tooltip contentStyle={{ background: "#11151f", border: "1px solid #242a3a", fontSize: 12 }} />
            <Bar dataKey="value" fill="#f59e0b" radius={[0, 4, 4, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </Card>
    </div>
  );
}

/* ---------------------------------- Team Roles Page ---------------------------------- */

function TeamRolesPage({ users, onAdd, onEdit, lang = "en" }) {
  const t = I18N[lang] || I18N.en;
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [role, setRole] = useState("Employee");
  const [editingId, setEditingId] = useState(null);

  function submit(e) {
    e.preventDefault();
    if (!name.trim() || !email.trim()) return;
    onAdd({ name: name.trim(), email: email.trim(), role, department: role === "Super Admin" || role === "Employee" ? null : role, active: true });
    setName(""); setEmail(""); setRole("Employee");
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <Eyebrow>ADMIN</Eyebrow>
      <h1 className="text-3xl font-bold text-slate-100 tracking-tight mb-1">{t.manageTeam}</h1>
      <p className="text-sm text-slate-400 mb-6">Roles determine access permissions. Deactivating preserves history.</p>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_300px] gap-6">
        <div className="space-y-3">
          {users.map((u) => (
            <Card key={u.id} className="p-4 flex items-center justify-between gap-3 flex-wrap">
              <div className="flex items-center gap-3 min-w-0">
                <div className="min-w-0">
                  <div className={`text-sm font-semibold ${u.active ? "text-slate-100" : "text-slate-500"}`}>{u.name}</div>
                  <div className="text-xs text-slate-500 font-mono truncate">{u.email}</div>
                </div>
                <Badge text={u.role} className="text-slate-300 bg-slate-500/10 border-slate-500/40 shrink-0" />
              </div>
              <div className="flex items-center gap-3 shrink-0">
                <label className="flex items-center gap-2 cursor-pointer select-none">
                  <span className="text-xs text-slate-500">{u.active ? t.active : t.inactive}</span>
                  <div onClick={() => onEdit(u.id, { active: !u.active })} className={`w-9 h-5 rounded-full relative transition-colors ${u.active ? "bg-amber-500" : "bg-[#2b3140]"}`}>
                    <div className={`w-3.5 h-3.5 bg-white rounded-full absolute top-0.5 transition-all ${u.active ? "left-4.5" : "left-0.5"}`} style={{ left: u.active ? "20px" : "2px" }} />
                  </div>
                </label>
                <button onClick={() => setEditingId(editingId === u.id ? null : u.id)} className="text-xs border border-[#242a3a] rounded px-3 py-1.5 text-slate-300 hover:bg-[#161b26]">{t.edit}</button>
              </div>
              {editingId === u.id && (
                <div className="w-full flex items-center gap-2 pt-2 border-t border-[#242a3a] mt-2">
                  <select className="bg-[#0d1119] border border-[#242a3a] rounded px-2 py-1.5 text-xs text-slate-300"
                    value={u.role}
                    onChange={(e) => { const r = e.target.value; onEdit(u.id, { role: r, department: (r === "Super Admin" || r === "Employee") ? null : r }); }}>
                    {["Super Admin", "HR", "HSE", "MGX", "Employee"].map((r) => <option key={r} value={r}>{r}</option>)}
                  </select>
                </div>
              )}
            </Card>
          ))}
        </div>

        <Card className="p-5 h-fit">
          <div className="flex items-center gap-2 mb-3">
            <Plus size={14} className="text-amber-500" />
            <span className="text-[11px] tracking-[0.15em] text-amber-500 font-semibold">{t.addMember}</span>
          </div>
          <form onSubmit={submit} className="space-y-3">
            <Field label={t.fullName}>
              <input className={inputCls} value={name} onChange={(e) => setName(e.target.value)} />
            </Field>
            <Field label={t.workEmail}>
              <input className={inputCls} placeholder="name@factory.com" value={email} onChange={(e) => setEmail(e.target.value)} />
            </Field>
            <Field label={t.role}>
              <select className={inputCls} value={role} onChange={(e) => setRole(e.target.value)}>
                {["Employee", "HR", "HSE", "MGX", "Super Admin"].map((r) => <option key={r} value={r}>{r}</option>)}
              </select>
            </Field>
            <button type="submit" className="w-full bg-amber-500 hover:bg-amber-400 text-[#0a0d13] font-bold rounded-md py-2.5 text-sm tracking-wide">{t.addMember}</button>
          </form>
        </Card>
      </div>
    </div>
  );
}

/* ---------------------------------- Login Page ---------------------------------- */

function LoginPage({ users, onLogin, lang = "en", setLang }) {
  const t = I18N[lang] || I18N.en;
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  function submit(e) {
    e.preventDefault();
    const u = users.find((x) => x.email.toLowerCase() === email.trim().toLowerCase());
    if (!u) { setError("No account found with that email."); return; }
    if (!u.active) { setError("This account has been deactivated."); return; }
    if (password !== DEMO_PASSWORD) { setError("Incorrect password."); return; }
    setError("");
    onLogin(u);
  }

  return (
    <div className="min-h-screen bg-[#0a0d13] flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="flex items-center justify-between mb-4 px-2">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-md bg-amber-500 flex items-center justify-center shadow-md">
              <HardHat size={20} className="text-[#0a0d13]" />
            </div>
            <div>
              <div className="text-lg font-bold text-slate-100 tracking-wide leading-none">NEAR MISS</div>
              <div className="text-[10px] text-slate-500 tracking-[0.15em]">PLANT SAFETY</div>
            </div>
          </div>

          <div className="flex items-center bg-[#11151f] border border-[#242a3a] rounded-lg p-1">
            {["en", "fr", "ar"].map((l) => (
              <button
                key={l}
                onClick={() => setLang(l)}
                className={`px-2 py-0.5 rounded text-xs font-bold uppercase transition-colors ${
                  lang === l ? "bg-amber-500 text-black" : "text-slate-400 hover:text-slate-200"
                }`}
              >
                {l}
              </button>
            ))}
          </div>
        </div>

        <Card className="p-6 shadow-xl">
          <Eyebrow>SIGN IN</Eyebrow>
          <h1 className="text-xl font-bold text-slate-100 mb-4">{t.welcomeBack}</h1>
          <form onSubmit={submit} className="space-y-4">
            <Field label={t.workEmail}>
              <input className={inputCls} placeholder="name@factory.com" value={email} onChange={(e) => setEmail(e.target.value)} />
            </Field>
            <Field label={t.password}>
              <input className={inputCls} type="password" placeholder="••••••••" value={password} onChange={(e) => setPassword(e.target.value)} />
            </Field>
            {error && <div className="text-sm text-red-400">{error}</div>}
            <button type="submit" className="w-full bg-amber-500 hover:bg-amber-400 text-[#0a0d13] font-semibold rounded-md py-2.5 text-sm transition-colors shadow-md">
              {t.signIn}
            </button>
          </form>
        </Card>

        <Card className="p-4 mt-4">
          <div className="text-[11px] text-slate-500 mb-2 tracking-wide">{t.demoAccounts} · password is <span className="text-slate-300 font-mono">{DEMO_PASSWORD}</span></div>
          <div className="grid grid-cols-1 gap-1">
            {users.map((u) => (
              <button
                key={u.id}
                onClick={() => { setEmail(u.email); setPassword(DEMO_PASSWORD); }}
                className="flex items-center justify-between text-left px-2 py-1.5 rounded hover:bg-[#191f2c] transition-colors"
              >
                <span className="text-sm text-slate-300">{u.name}{!u.active && <span className="text-slate-600"> (inactive)</span>}</span>
                <span className="text-[11px] text-slate-500 font-mono">{u.role}</span>
              </button>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

/* ---------------------------------- App Entrypoint ---------------------------------- */

export default function App() {
  const [loading, setLoading] = useState(true);
  const [users, setUsers] = useState(SEED_USERS);
  const [incidents, setIncidents] = useState([]);
  const [nextSeq, setNextSeq] = useState(126);
  const [currentUser, setCurrentUser] = useState(null);
  const [page, setPage] = useState("dashboard");
  const [selectedId, setSelectedId] = useState(null);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [lang, setLang] = useState(() => {
    try {
      return localStorage.getItem("nearmiss-lang") || "en";
    } catch {
      return "en";
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem("nearmiss-lang", lang);
    } catch {}
  }, [lang]);

  useEffect(() => {
    (async () => {
      try {
        let savedData = null;
        if (typeof window !== "undefined" && window.storage && typeof window.storage.get === "function") {
          const res = await window.storage.get("nearmiss-data", false);
          if (res && res.value) {
            savedData = JSON.parse(res.value);
          }
        } else if (typeof localStorage !== "undefined") {
          const stored = localStorage.getItem("nearmiss-data");
          if (stored) {
            savedData = JSON.parse(stored);
          }
        }
        if (savedData) {
          setUsers(savedData.users || SEED_USERS);
          setIncidents(savedData.incidents || makeSeedIncidents());
          setNextSeq(savedData.nextSeq || 126);
        } else {
          setIncidents(makeSeedIncidents());
        }
      } catch (e) {
        setIncidents(makeSeedIncidents());
      }
      setLoading(false);
    })();
  }, []);

  useEffect(() => {
    if (loading) return;
    (async () => {
      try {
        const payload = JSON.stringify({ users, incidents, nextSeq });
        if (typeof window !== "undefined" && window.storage && typeof window.storage.set === "function") {
          await window.storage.set("nearmiss-data", payload, false);
        } else if (typeof localStorage !== "undefined") {
          localStorage.setItem("nearmiss-data", payload);
        }
      } catch (e) {}
    })();
  }, [users, incidents, nextSeq, loading]);

  const selectedIncident = incidents.find((i) => i.id === selectedId);
  const openIncidentsCount = incidents.filter(i => i.status === "Open" || i.status === "In Review").length;

  function handleSubmitIncident(payload) {
    const seq = nextSeq;
    const departments = ROUTING[payload.type] || ["HSE"];
    const assignments = departments.map((d) => ({ department: d, status: "Open", resolvedAt: null }));
    const incident = {
      id: `inc-${seq}`, number: fmtId(seq), seq,
      title: payload.title, description: payload.description, type: payload.type,
      severity: payload.severity, location: payload.location, reportedBy: payload.reportedBy,
      incidentDate: payload.incidentDate, createdAt: new Date().toISOString(), status: "Open",
      assignments, comments: [], investigation: {}, attachments: payload.attachments || [],
      auditLog: [
        { action: "Incident created", user: payload.reportedBy, date: new Date().toISOString(), oldValue: null, newValue: null },
        { action: `Assigned to ${departments.join(" and ")}`, user: "System", date: new Date().toISOString(), oldValue: null, newValue: null },
      ],
    };
    setIncidents((prev) => [incident, ...prev]);
    setNextSeq((n) => n + 1);
    return incident;
  }

  function updateAssignmentStatus(incidentId, department, newStatus) {
    setIncidents((prev) => prev.map((inc) => {
      if (inc.id !== incidentId) return inc;
      const oldAssign = inc.assignments.find((a) => a.department === department);
      const assignments = inc.assignments.map((a) => a.department === department
        ? { ...a, status: newStatus, resolvedAt: (newStatus === "Resolved" || newStatus === "Closed") ? new Date().toISOString() : a.resolvedAt }
        : a);
      const overall = inc.status === "Closed" ? "Closed" : deriveOverallStatus(assignments);
      return {
        ...inc, assignments, status: overall,
        auditLog: [...inc.auditLog, {
          action: `${department} status changed`, user: currentUser.name,
          date: new Date().toISOString(), oldValue: oldAssign.status, newValue: newStatus,
        }],
      };
    }));
  }

  function addComment(incidentId, text) {
    setIncidents((prev) => prev.map((inc) => inc.id !== incidentId ? inc : {
      ...inc,
      comments: [...inc.comments, { author: currentUser.name, department: currentUser.department, text, date: new Date().toISOString() }],
      auditLog: [...inc.auditLog, { action: "Comment added", user: currentUser.name, date: new Date().toISOString(), oldValue: null, newValue: null }],
    }));
  }

  function addAttachmentToIncident(incidentId, attachment) {
    setIncidents((prev) => prev.map((inc) => inc.id !== incidentId ? inc : {
      ...inc,
      attachments: [...(inc.attachments || []), attachment],
      auditLog: [...(inc.auditLog || []), { action: `Photo/Evidence attached: ${attachment.name}`, user: currentUser.name, date: new Date().toISOString(), oldValue: null, newValue: null }],
    }));
  }

  function saveInvestigation(incidentId, department, data) {
    setIncidents((prev) => prev.map((inc) => inc.id !== incidentId ? inc : {
      ...inc,
      investigation: { ...(inc.investigation || {}), [department]: data },
      auditLog: [...(inc.auditLog || []), { action: `${department} investigation notes updated`, user: currentUser.name, date: new Date().toISOString(), oldValue: null, newValue: null }],
    }));
  }

  function closeIncident(incidentId) {
    setIncidents((prev) => prev.map((inc) => inc.id !== incidentId ? inc : {
      ...inc, status: "Closed",
      auditLog: [...(inc.auditLog || []), { action: "Incident closed", user: currentUser.name, date: new Date().toISOString(), oldValue: "Resolved", newValue: "Closed" }],
    }));
  }

  function addUser(payload) {
    setUsers((prev) => [...prev, { id: `u${Date.now()}`, ...payload }]);
  }
  function editUser(id, patch) {
    setUsers((prev) => prev.map((u) => u.id === id ? { ...u, ...patch } : u));
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0d13] flex items-center justify-center">
        <Loader2 className="animate-spin text-amber-500" size={28} />
      </div>
    );
  }

  if (!currentUser) {
    return <LoginPage users={users} onLogin={(u) => { setCurrentUser(u); setPage("dashboard"); }} lang={lang} setLang={setLang} />;
  }

  const isRtl = lang === "ar";

  return (
    <div className="min-h-screen bg-[#0a0d13] font-sans flex text-slate-100 overflow-x-hidden" dir={isRtl ? "rtl" : "ltr"}>
      <SidebarNavigation
        page={page}
        setPage={(p) => { setPage(p); setSelectedId(null); }}
        user={currentUser}
        onLogout={() => setCurrentUser(null)}
        collapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
        openIncidentsCount={openIncidentsCount}
        lang={lang}
      />

      <div className="flex-1 flex flex-col min-w-0">
        <TopHeader
          page={page}
          user={currentUser}
          onLogout={() => setCurrentUser(null)}
          sidebarCollapsed={sidebarCollapsed}
          onToggleSidebar={() => setSidebarCollapsed(!sidebarCollapsed)}
          lang={lang}
          setLang={setLang}
        />

        <main className="flex-1 overflow-y-auto">
          {page === "dashboard" && <DashboardPage incidents={incidents} user={currentUser} lang={lang} />}
          {page === "report" && <ReportPage user={currentUser} onSubmit={handleSubmitIncident} lang={lang} />}
          {page === "incidents" && !selectedIncident && (
            <IncidentsPage incidents={incidents} user={currentUser} onOpen={(id) => setSelectedId(id)} lang={lang} />
          )}
          {page === "incidents" && selectedIncident && (
            <IncidentDetailPage
              incident={selectedIncident} user={currentUser}
              onBack={() => setSelectedId(null)}
              onUpdateAssignment={updateAssignmentStatus}
              onAddComment={addComment}
              onCloseIncident={closeIncident}
              onSaveInvestigation={saveInvestigation}
              onAddAttachment={addAttachmentToIncident}
              lang={lang}
            />
          )}
          {page === "insights" && <InsightsPage incidents={incidents} user={currentUser} lang={lang} />}
          {page === "team" && currentUser.role === "Super Admin" && (
            <TeamRolesPage users={users} onAdd={addUser} onEdit={editUser} lang={lang} />
          )}
        </main>
      </div>
    </div>
  );
}
