import os
import sys
from fpdf import FPDF

class DeploymentGuidePDF(FPDF):
    def __init__(self):
        super().__init__(orientation="P", unit="mm", format="A4")
        self.set_auto_page_break(auto=True, margin=15)
        self.set_margins(left=15, top=15, right=15)

    def header(self):
        if self.page_no() > 1:
            self.set_font("Helvetica", "I", 8)
            self.set_text_color(120, 130, 145)
            self.cell(0, 8, "Near Miss Safety App - Standard Local & Corporate Deployment Guide", align="L")
            self.ln(8)

    def footer(self):
        self.set_y(-12)
        self.set_font("Helvetica", "", 8)
        self.set_text_color(140, 150, 165)
        self.cell(0, 10, f"Page {self.page_no()} of {{nb}}  |  Corporate Intranet / On-Premise SOP", align="C")

    def chapter_title(self, num, title):
        self.set_font("Helvetica", "B", 13)
        self.set_fill_color(241, 245, 249) # slate 100
        self.set_text_color(15, 23, 42) # slate 900
        self.cell(0, 9, f"  {num}. {title}", fill=True, ln=True)
        self.ln(3)

    def section_title(self, title):
        self.set_font("Helvetica", "B", 10.5)
        self.set_text_color(30, 41, 59)
        self.cell(0, 7, title, ln=True)
        self.ln(1)

    def body_text(self, text):
        self.set_font("Helvetica", "", 9.5)
        self.set_text_color(51, 65, 85)
        self.multi_cell(0, 5, text)
        self.ln(2)

    def alert_box(self, title, text, bg_color=(254, 252, 232), border_color=(202, 138, 4), text_color=(133, 77, 14)):
        self.set_fill_color(*bg_color)
        self.set_draw_color(*border_color)
        self.set_line_width(0.4)
        
        y_start = self.get_y()
        self.set_font("Helvetica", "B", 9)
        self.set_text_color(*text_color)
        self.multi_cell(0, 4.5, f"{title}: {text}", fill=True, border=1)
        self.set_line_width(0.2)
        self.set_draw_color(200, 200, 200)
        self.ln(3)

    def code_box(self, code_lines):
        self.set_fill_color(15, 23, 42) # slate 900
        self.set_text_color(226, 232, 240) # slate 200
        self.set_font("Courier", "", 8.5)
        self.set_draw_color(30, 41, 59)
        
        text = "\n".join(code_lines)
        self.multi_cell(0, 4.5, text, fill=True, border=1)
        self.ln(3)

    def draw_table(self, headers, rows, col_widths):
        self.set_font("Helvetica", "B", 8.5)
        self.set_fill_color(241, 245, 249)
        self.set_text_color(15, 23, 42)
        self.set_draw_color(203, 213, 225)

        for i, header in enumerate(headers):
            self.cell(col_widths[i], 6.5, header, border=1, fill=True, align="C")
        self.ln()

        self.set_font("Helvetica", "", 8.5)
        fill = False
        for row in rows:
            self.set_fill_color(248, 250, 252) if fill else self.set_fill_color(255, 255, 255)
            self.set_text_color(30, 41, 59)
            for i, cell_val in enumerate(row):
                self.cell(col_widths[i], 6, str(cell_val), border=1, fill=fill, align="L" if i > 0 else "C")
            self.ln()
            fill = not fill
        self.ln(3)

def build_pdf():
    pdf = DeploymentGuidePDF()
    pdf.alias_nb_pages()
    pdf.add_page()

    # --- TITLE HEADER ---
    pdf.set_fill_color(15, 23, 42) # Slate 900
    pdf.rect(15, 15, 180, 24, "F")
    
    # Yellow decorative bar
    pdf.set_fill_color(245, 158, 11) # Amber 500
    pdf.rect(15, 15, 4, 24, "F")

    pdf.set_xy(23, 19)
    pdf.set_font("Helvetica", "B", 14)
    pdf.set_text_color(248, 250, 252)
    pdf.cell(0, 6, "NEAR MISS SAFETY APP - LOCAL DEPLOYMENT GUIDE", ln=True)

    pdf.set_xy(23, 26)
    pdf.set_font("Helvetica", "", 8.5)
    pdf.set_text_color(148, 163, 184)
    pdf.cell(0, 5, "Standard Operating Procedure (SOP) for Corporate Intranet & On-Premise Hosting", ln=True)

    pdf.set_y(44)

    # --- INTRO ALERT ---
    pdf.alert_box(
        "AI & HUMAN DEVELOPER READY",
        "This guide contains verified, copy-paste instructions for deploying the Near Miss Safety application onto any local machine or corporate server. It is structured to be universally interpreted by developers, DevOps, and LLMs (Claude, ChatGPT, Antigravity).",
        bg_color=(239, 246, 255),
        border_color=(37, 99, 235),
        text_color=(30, 64, 175)
    )

    # --- CHAPTER 1 ---
    pdf.chapter_title("1", "Architecture & Environment Overview")
    pdf.body_text(
        "The application is built with React 18, Vite, and TailwindCSS. In production, we do NOT use 'npm run dev' (development port 5173). Instead, the app is compiled into optimized static assets ('dist' folder) and served via Nginx or Node.js."
    )

    headers = ["Environment", "Port", "Web Server", "Target Users", "Persistence"]
    rows = [
        ["Development", "5173", "Vite Dev", "Individual Developer", "Stops on exit"],
        ["Docker (Standard)", "80", "Nginx Alpine", "All Company Staff", "24/7 Auto-restart"],
        ["Docker (Alt)", "3000 / 8080", "Nginx Alpine", "If Port 80 is busy", "24/7 Auto-restart"],
        ["Windows Native", "3000", "Node serve + PM2", "Staff (No Docker)", "Windows Service"]
    ]
    col_widths = [32, 22, 34, 46, 46]
    pdf.draw_table(headers, rows, col_widths)

    # --- CHAPTER 2 ---
    pdf.chapter_title("2", "Method A: Docker Deployment (Recommended Standard)")
    pdf.body_text(
        "Docker ensures 100% consistency across Windows, Linux, and macOS servers. The containerized setup uses a multi-stage Dockerfile and Nginx Alpine."
    )

    pdf.section_title("Key Files Configured in the Project:")
    pdf.body_text(
        "- Dockerfile: Compiles React with Node 20, then copies 'dist' to Nginx Alpine.\n"
        "- nginx.conf: Handles SPA routing (try_files $uri /index.html) and Gzip compression.\n"
        "- .dockerignore: Excludes node_modules to ensure fast, lightweight build context.\n"
        "- docker-compose.yml: Binds host port 80 to container port 80 with restart policy."
    )

    pdf.section_title("Step-by-Step Command Lines:")
    pdf.code_box([
        "# 1. Navigate to the project directory:",
        "cd /path/to/TEST",
        "",
        "# 2. Build the Docker image and start the container in background:",
        "docker compose up -d --build",
        "",
        "# 3. Verify the container is running and healthy:",
        "docker ps",
        "",
        "# 4. View live access and runtime logs:",
        "docker logs -f near_miss_safety_app"
    ])

    pdf.body_text("Once started, access the app locally at: http://localhost (Port 80 is standard HTTP).")

    # --- CHAPTER 3 ---
    pdf.chapter_title("3", "Method B: Native Windows Server Deployment (Without Docker)")
    pdf.body_text(
        "If Docker Desktop is not installed on the server, you can run the app directly using Node.js and PM2 as a continuous Windows Service:"
    )

    pdf.code_box([
        "# Step 1: Build the production bundle (creates the 'dist' directory)",
        "npm.cmd run build",
        "",
        "# Step 2: Install production static server and PM2 process manager globally",
        "npm install -g serve pm2 pm2-windows-startup",
        "pm2-startup install",
        "",
        "# Step 3: Launch the app on port 3000 with SPA routing",
        "pm2 serve dist 3000 --name \"near-miss-app\" --spa",
        "",
        "# Step 4: Save PM2 configuration to survive Windows restarts",
        "pm2 save"
    ])

    # --- NEW PAGE ---
    pdf.add_page()

    # --- CHAPTER 4 ---
    pdf.chapter_title("4", "Method C: Dedicated Linux Server (Ubuntu / Debian + Nginx)")
    pdf.body_text("For native Linux server instances (e.g. AWS EC2, Proxmox, or local Ubuntu Server):")

    pdf.code_box([
        "# 1. Install Nginx web server",
        "sudo apt update && sudo apt install -y nginx",
        "",
        "# 2. Copy the pre-built 'dist' folder to Nginx web root",
        "sudo cp -r dist/* /var/www/html/",
        "",
        "# 3. Ensure Nginx fallback is configured in /etc/nginx/sites-available/default:",
        "location / {",
        "    try_files $uri $uri/ /index.html;",
        "}",
        "",
        "# 4. Test configuration and restart Nginx",
        "sudo nginx -t && sudo systemctl restart nginx",
        "sudo ufw allow 80/tcp"
    ])

    # --- CHAPTER 5 ---
    pdf.chapter_title("5", "Company Local Network Access (Allowing All Employees to Connect)")
    pdf.body_text(
        "To allow every employee on the company Wi-Fi or local network to access the application:"
    )

    pdf.section_title("Step 1: Retrieve the Server's IP Address")
    pdf.body_text("On the server machine, run:")
    pdf.code_box([
        "# On Windows Server / PC:",
        "ipconfig",
        "# Note down the IPv4 Address (e.g., 192.168.1.120 or 10.0.0.50)",
        "",
        "# On Linux Server:",
        "hostname -I"
    ])

    pdf.section_title("Step 2: Open Inbound Firewall Port")
    pdf.body_text("Windows and Linux block incoming connections by default. Run this on the server:")
    pdf.code_box([
        "# Windows PowerShell (Run as Administrator):",
        "New-NetFirewallRule -DisplayName \"Near Miss Safety App\" -Direction Inbound -LocalPort 80,3000 -Protocol TCP -Action Allow",
        "",
        "# Linux (UFW):",
        "sudo ufw allow 80/tcp"
    ])

    pdf.section_title("Step 3: Employee Access URL")
    pdf.body_text(
        "Distribute the URL to coworkers: http://<SERVER_IP_ADDRESS>  (e.g., http://192.168.1.120)\n"
        "If using an alternative port like 3000, coworkers visit: http://192.168.1.120:3000"
    )

    # --- CHAPTER 6 ---
    pdf.chapter_title("6", "Troubleshooting Guide & FAQ")
    
    headers_tb = ["Symptom", "Probable Cause", "Solution"]
    rows_tb = [
        ["ERR_CONNECTION_REFUSED", "Server or container is stopped", "Run 'docker compose up -d' or check PM2 status."],
        ["Port 80 conflict error", "IIS or Skype using Port 80", "Edit docker-compose.yml to '3000:80', then re-run compose."],
        ["Coworkers cannot reach IP", "Firewall blocking or Wi-Fi guest isolation", "Run firewall allow command; ensure PC is on corporate LAN."],
        ["404 on page refresh", "Missing SPA rewrite rule", "Verify Nginx has 'try_files $uri $uri/ /index.html'."],
        ["Update code in Docker", "Source code modified", "Run 'docker compose up -d --build' to rebuild & swap image."]
    ]
    col_widths_tb = [45, 50, 85]
    pdf.draw_table(headers_tb, rows_tb, col_widths_tb)

    pdf.alert_box(
        "DATA PERSISTENCE NOTE",
        "Currently, this React app operates as an optimized client-side SPA. For permanent centralized incident storage across different shifts and departments, connect a shared backend database (such as SQLite, Express API, or PocketBase) on the server.",
        bg_color=(254, 243, 199),
        border_color=(217, 119, 6),
        text_color=(146, 64, 14)
    )

    output_path = os.path.join(os.getcwd(), "Local_Deployment_Guide.pdf")
    pdf.output(output_path)
    print(f"SUCCESS: PDF generated at: {output_path}")

if __name__ == "__main__":
    build_pdf()
