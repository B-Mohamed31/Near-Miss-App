@echo off
title Near Miss Safety App Server
echo ===================================================
echo   Starting Near Miss Safety App...
echo   App URL: http://localhost:5173
echo   (Keep this window open while using the app)
echo ===================================================
timeout /t 2 >nul
start http://localhost:5173
call npm.cmd run dev
pause
