/*
 * Bridges the app's built-in window.storage.get/set/delete/list calls
 * (see src/App.jsx) to the backend's shared SQLite-backed API, so every
 * browser/employee reads and writes the SAME dataset instead of each
 * browser's own localStorage.
 */
(function () {
  async function request(path, options) {
    const res = await fetch(path, options);
    if (res.status === 404) return null;
    if (!res.ok) throw new Error("storage request failed: " + res.status);
    return res.json();
  }

  window.storage = {
    get: (key) => request(`/api/storage/${encodeURIComponent(key)}`),
    set: (key, value) =>
      request(`/api/storage/${encodeURIComponent(key)}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ value }),
      }),
    delete: (key) =>
      request(`/api/storage/${encodeURIComponent(key)}`, { method: "DELETE" }),
    list: (prefix) =>
      request(`/api/storage?prefix=${encodeURIComponent(prefix || "")}`),
  };
})();
