const path = require("path");
const fs = require("fs");
const express = require("express");
const cors = require("cors");
const Database = require("better-sqlite3");

// The DB file lives in a Docker volume (see docker-compose.yml) so data
// survives container restarts, rebuilds, and reboots.
const DB_PATH = process.env.DB_PATH || path.join(__dirname, "data", "nearmiss.db");
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

const db = new Database(DB_PATH);
db.pragma("journal_mode = WAL");
db.exec(`
  CREATE TABLE IF NOT EXISTS kv_store (
    key        TEXT PRIMARY KEY,
    value      TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );
`);

const getStmt = db.prepare("SELECT value FROM kv_store WHERE key = ?");
const listStmt = db.prepare("SELECT key FROM kv_store WHERE key LIKE ? ORDER BY key");
const upsertStmt = db.prepare(`
  INSERT INTO kv_store (key, value, updated_at) VALUES (?, ?, datetime('now'))
  ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
`);
const deleteStmt = db.prepare("DELETE FROM kv_store WHERE key = ?");

const app = express();
app.use(cors());
app.use(express.json({ limit: "50mb" })); // incident photos are base64, keep the limit generous

// Every browser/employee hits the SAME database file -> one shared dataset.

app.get("/api/health", (_req, res) => res.json({ status: "ok" }));

app.get("/api/storage/:key", (req, res) => {
  const row = getStmt.get(req.params.key);
  if (!row) return res.status(404).json({ error: "not_found" });
  res.json({ key: req.params.key, value: row.value, shared: true });
});

app.post("/api/storage/:key", (req, res) => {
  const { value } = req.body || {};
  if (typeof value !== "string") {
    return res.status(400).json({ error: "value must be a JSON string" });
  }
  upsertStmt.run(req.params.key, value);
  res.json({ key: req.params.key, value, shared: true });
});

app.delete("/api/storage/:key", (req, res) => {
  deleteStmt.run(req.params.key);
  res.json({ key: req.params.key, deleted: true, shared: true });
});

app.get("/api/storage", (req, res) => {
  const prefix = req.query.prefix || "";
  const rows = listStmt.all(`${prefix}%`);
  res.json({ keys: rows.map((r) => r.key), prefix, shared: true });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Near Miss backend listening on :${PORT}`));
